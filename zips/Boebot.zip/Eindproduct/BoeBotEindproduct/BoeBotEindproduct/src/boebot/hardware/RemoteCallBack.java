package boebot.hardware;

public interface RemoteCallBack {
    void onButtonPress(int code);
}
