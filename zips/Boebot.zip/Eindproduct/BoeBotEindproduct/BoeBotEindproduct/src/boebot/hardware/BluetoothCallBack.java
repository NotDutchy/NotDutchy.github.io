package boebot.hardware;

public interface BluetoothCallBack {
    void onButtonPress(String command, String extraMessage);
}
