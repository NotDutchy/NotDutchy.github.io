package boebot.interfaces.navigation.bluetoothNavigator.commands;

import TI.BoeBot;
import TI.Timer;
import boebot.config.Configuration;
import boebot.hardware.servo.ServoStatus;
import boebot.interfaces.Driver;
import boebot.interfaces.navigation.BluetoothNavigator;
import boebot.interfaces.navigation.bluetoothNavigator.Command;

public class Forward implements Command {
    private final BluetoothNavigator bluetoothNavigator;
    private boolean atCrossSection;
    private boolean finalStage;
    private Timer finishTimer;
    private Timer updateTimer;

    public Forward(BluetoothNavigator bluetoothNavigator) {
        this.bluetoothNavigator = bluetoothNavigator;
        atCrossSection = true;
        finalStage = false;
        updateTimer = new Timer(50);
    }

    @Override
    public void start() {
        update();
    }

    /**
     * Method that is used for the command forward.
     * First it'll check if the BoeBot is not at an intersection and initiate a second timer. This timer is used to determine when the BoeBot should stop moving.
     * If the BoeBot is not at an intersection it will move forward until it sees the next intersection.
     */
    @Override
    public void update() {
        if(!updateTimer.timeout())
            return;
        ServoStatus servoStatus = bluetoothNavigator.getLineFollower().getAdvice();
        Driver driver = bluetoothNavigator.getDriver();
        Configuration config = bluetoothNavigator.getConfig();
        if(servoStatus.equals(ServoStatus.DONT_MOVE) && !atCrossSection) {
            finishTimer = new Timer(200);
            driver.change(ServoStatus.FORWARD, 40, 40);
            driver.makeSameSpeed();
        }
        if(finishTimer != null && finishTimer.timeout()) {
            driver.change(ServoStatus.DONT_MOVE,0,200);
            driver.makeSameSpeed();
            bluetoothNavigator.commandCallBack(this);
        } else {
            if(servoStatus.equals(ServoStatus.DONT_MOVE)) {
                driver.change(ServoStatus.FORWARD, 40, 5);
            } else {
                driver.change(servoStatus, 40, 5);
            }
            driver.makeSameSpeed();
            atCrossSection = servoStatus.equals(ServoStatus.DONT_MOVE);
        }
    }
}
