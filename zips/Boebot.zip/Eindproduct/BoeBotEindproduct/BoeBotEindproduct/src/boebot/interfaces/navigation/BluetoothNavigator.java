package boebot.interfaces.navigation;

import TI.BoeBot;
import TI.PinMode;
import TI.Servo;
import TI.Timer;
import boebot.config.Configuration;
import boebot.hardware.Bluetooth;
import boebot.hardware.BluetoothCallBack;
import boebot.hardware.RemoteCallBack;
import boebot.hardware.servo.ServoStatus;
import boebot.interfaces.*;
import boebot.interfaces.navigation.bluetoothNavigator.Command;
import boebot.interfaces.navigation.bluetoothNavigator.CommandCallBack;
import boebot.interfaces.navigation.bluetoothNavigator.Commands;
import boebot.interfaces.obstacledetector.ObstacleDetector;
import boebot.interfaces.obstacledetector.UltraSoneDetector;

import java.awt.*;
import java.util.ArrayList;
import java.util.Arrays;


public class BluetoothNavigator implements Updateable, Navigation, GripperCallback, CommandCallBack {
    private Configuration config;
    private Driver driver;
    private UltraSoneDetector ultraSoneDetectorDown;
    private UltraSoneDetector ultraSoneDetectorUp;
    private LineFollower lineFollower;
    private Gripper gripper;
    private Bluetooth bluetooth;
    private ArrayList<Command> route;
    private Command currentCommand;
    private boolean isStarted;
    private Timer updateLineFollower;

    public BluetoothNavigator(Configuration config) {
        isStarted = false;
        this.config = config;
        BoeBot.rgbSet(config.getModeLedPin(), Color.BLUE);
        BoeBot.rgbShow();
        updateLineFollower = new Timer(20);
    }

    @Override
    public void OnGripperOpen() {

    }

    @Override
    public void OnGripperClose() {

    }

    /**
     * Update method for BluetoothNavigator
     */
    @Override
    public void update() {
        if(!isStarted)
            return;
        if(!this.ultraSoneDetectorUp.isObstacleNear()) {
            if (updateLineFollower.timeout()) {
                lineFollower.update();
            }
            if(this.currentCommand != null)
                this.currentCommand.update();
        }
        gripper.update();
        ultraSoneDetectorDown.update();
        ultraSoneDetectorUp.update();
        bluetooth.update();
    }

    /**
     * It will get the next command out of the commands
     */
    public void nextCommand() {
        BoeBot.wait(2000);
        if(route.size() > 0) {
            this.currentCommand = route.get(0);
            System.out.println("Command updated to " + route.get(0).toString());
            this.currentCommand.start();
            route.remove(0);
        } else {
            System.out.println("No more commands");
            //TODO stop process
            this.currentCommand = null;
        }
    }

    /**
     * When an obstacle is detected, it will override the current driver and make the robot stop.
     * @param obstacleDetector
     */
    @Override
    public void obstacleCallBack(ObstacleDetector obstacleDetector) {
        if(obstacleDetector instanceof UltraSoneDetector) {
            UltraSoneDetector ultraSoneDetector = (UltraSoneDetector) obstacleDetector;
            Driver tempDriver = new Driver(this.config);
            tempDriver.change(ServoStatus.DONT_MOVE,0,200);
            tempDriver.makeSameSpeed();
            System.out.println("stop");

        }
    }

    /**
     * When an command is finished it will go to the next command.
     * @param command
     */
    @Override
    public void commandCallBack(Command command) {
        System.out.println("Callback command");
        nextCommand();
    }

    public Configuration getConfig() {
        return config;
    }

    public Driver getDriver() {
        return driver;
    }

    public UltraSoneDetector getUltraSoneDetectorDown() {
        return ultraSoneDetectorDown;
    }

    public UltraSoneDetector getUltraSoneDetectorUp() {
        return ultraSoneDetectorUp;
    }

    public LineFollower getLineFollower() {
        return lineFollower;
    }

    public Gripper getGripper() {
        return gripper;
    }

    public Bluetooth getBluetooth() {
        return bluetooth;
    }

    public ArrayList<Command> getRoute() {
        return route;
    }

    public Command getCurrentCommand() {
        return currentCommand;
    }

    /**
     * When the start navigator button is pressed the navigator will start
     */
    @Override
    public void start() {
        isStarted = true;
        this.config = config;
        this.driver = new Driver(config);
        this.driver.change(ServoStatus.DONT_MOVE,0,200);
        this.driver.makeSameSpeed();
        this.gripper = new Gripper(config.getGripperServoPin(), 3, this);
        this.bluetooth = new Bluetooth(this.config);
        this.currentCommand = null;
        this.route = new ArrayList<>();
        this.route.clear();
        this.ultraSoneDetectorUp = new UltraSoneDetector(this.config.getUpperUltraSoneTrigPin(), this.config.getUpperUltraSoneEchoPin(), this,20);
        this.ultraSoneDetectorDown = new UltraSoneDetector(this.config.getDownUltraSoneTrigPin(), this.config.getDownUltraSoneEchoPin(), this,5);
        this.lineFollower = new LineFollower(config);
        this.bluetooth.registerCallBack("Route", (commandMes, extraMessage) -> {
            if(extraMessage.startsWith("/")) {
                extraMessage = extraMessage.replaceFirst("/", "");
                route = new ArrayList<>();
                Arrays.stream(extraMessage.split(",")).forEach(commandString -> {
                    Command command = Commands.getCommand(commandString, this);
                    if(command != null) {
                        route.add(command);
                        System.out.println("Command added: " + commandString);
                    } else {
                        System.out.println("Could not find Command for [" + commandString + "]");
                    }
                });
                nextCommand();
            }
        });

        //route = new ArrayList<>(Arrays.asList(Commands.getCommand("w", this), Commands.getCommand("w", this), Commands.getCommand("a",this), Commands.getCommand("w",this)));
        //nextCommand();

        this.bluetooth.registerCallBack("EM", (command, extraMessage) -> {
            this.driver.change(ServoStatus.DONT_MOVE,0);
            this.driver.makeSameSpeed();
            this.currentCommand = null;
            this.route.clear();
        });
    }

}
