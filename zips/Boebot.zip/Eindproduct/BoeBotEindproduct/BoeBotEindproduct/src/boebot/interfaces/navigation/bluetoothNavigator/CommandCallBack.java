package boebot.interfaces.navigation.bluetoothNavigator;

import boebot.interfaces.Button;

public interface CommandCallBack {
    void commandCallBack(Command command);
}
