package boebot.interfaces.obstacledetector;

public interface ObstacleDetector {
    boolean isObstacleNear();
    boolean isFirstTime();
    void update();


}
