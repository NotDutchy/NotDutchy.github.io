package boebot.interfaces.navigation.bluetoothNavigator.commands;

import boebot.config.Configuration;
import boebot.hardware.servo.ServoStatus;
import boebot.interfaces.Driver;
import boebot.interfaces.navigation.BluetoothNavigator;
import boebot.interfaces.navigation.bluetoothNavigator.Command;

public class Backwards implements Command {
    private final BluetoothNavigator bluetoothNavigator;
    private boolean atCrossSection;

    public Backwards(BluetoothNavigator bluetoothNavigator) {
        this.bluetoothNavigator = bluetoothNavigator;
        atCrossSection = false;

    }

    @Override
    public void start() {
        update();

    }

    /**
     * This method is used whenever the command for backwards is initiated through bluetooth.
     * It'll check for intersections to determine if the command has been completed.
     * We have to invert the commands because our line follower class always thinks the robot is moving forward.
     */
    @Override
    public void update() {
        ServoStatus servoStatus = bluetoothNavigator.getLineFollower().getAdvice();
        Driver driver = bluetoothNavigator.getDriver();
        Configuration config = bluetoothNavigator.getConfig();
        if(servoStatus.equals(ServoStatus.DONT_MOVE) && !atCrossSection) {
            bluetoothNavigator.commandCallBack(this);
            return;
        }
        if(servoStatus.equals(driver.getServoStatus()))
            return;
        System.out.println(servoStatus.toString());
        switch (servoStatus) {
            case DONT_MOVE:
            case FORWARD:
                driver.change(ServoStatus.BACKWARDS, config.getRandomRouteMaxForwardSpeed(), 200);
                driver.makeSameSpeed();
                break;
            case BACKWARDS:
                driver.change(ServoStatus.FORWARD, config.getRandomRouteMaxBackwardsSpeed(), 200);
                driver.makeSameSpeed();
                break;
            case ROTATE_LEFT:
            case ROTATE_LEFT_BACKWARDS:
            case ROTATE_RIGHT_BACKWARDS:
            case ROTATE_LEFT_FORWARD:
            case ROTATE_RIGHT_FORWARD:
            case ROTATE_RIGHT:
                driver.change(servoStatus, 40, 40);
                driver.makeSameSpeed();
                break;
        }
        atCrossSection = servoStatus.equals(ServoStatus.DONT_MOVE);
    }
}
