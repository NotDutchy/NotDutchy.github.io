package boebot.interfaces.navigation.bluetoothNavigator;

import boebot.interfaces.Updateable;

public interface Command extends Updateable {
    void start();

}
