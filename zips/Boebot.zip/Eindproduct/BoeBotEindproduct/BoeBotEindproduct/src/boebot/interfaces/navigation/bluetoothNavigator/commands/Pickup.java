package boebot.interfaces.navigation.bluetoothNavigator.commands;
import boebot.interfaces.Gripper;
import boebot.interfaces.navigation.BluetoothNavigator;
import boebot.interfaces.navigation.bluetoothNavigator.Command;
import boebot.interfaces.obstacledetector.UltraSoneDetector;

public class Pickup implements Command {
    private UltraSoneDetector ultraSoneDetectorBottom;
    private UltraSoneDetector ultraSoneDetectorTop;
    private BluetoothNavigator bluetoothNavigator;
    private Gripper gripper;

    public Pickup(BluetoothNavigator bluetoothNavigator) {
        this.bluetoothNavigator = bluetoothNavigator;
        this.ultraSoneDetectorBottom = this.bluetoothNavigator.getUltraSoneDetectorDown();
        this.ultraSoneDetectorTop = this.bluetoothNavigator.getUltraSoneDetectorUp();
        this.gripper = bluetoothNavigator.getGripper();
    }

    @Override
    public void start() {
        update();
    }

    /**
     * If object is near enough so the gripper can grab it the gripper will close it's claws.
     */
    @Override
    public void update() {
        if(this.ultraSoneDetectorBottom.isObstacleNear() && !this.ultraSoneDetectorTop.isObstacleNear()) {
            this.gripper.close();
        }
    }
}
