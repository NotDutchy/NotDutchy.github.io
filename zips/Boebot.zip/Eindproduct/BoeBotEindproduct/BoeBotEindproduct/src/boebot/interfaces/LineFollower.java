package boebot.interfaces;

import TI.BoeBot;
import TI.Timer;
import boebot.config.Configuration;
import boebot.hardware.servo.ServoStatus;

import java.awt.*;

public class LineFollower implements Updateable {
    private Configuration config;
    private int leftPin;
    private int middlePin;
    private int rightPin;
    private int lineFollowerThreshold;

    private boolean leftTriggered;
    private boolean middleTriggered;
    private boolean rightTriggered;

    /**
     * This is a linefollower and the only purpose is to give advice.
     * @param config
     */
    public LineFollower(Configuration config) {
        this.config = config;
        this.leftPin = config.getLeftLineFollowerPin();
        this.middlePin = config.getMiddleLineFollowerPin();
        this.rightPin = config.getRightLineFollowerPin();
        this.lineFollowerThreshold = config.getLineFollowerThreshold();
    }

    /**
     * Update method for the LineFollower
     */
    @Override
    public void update() {
        leftTriggered = BoeBot.analogRead(this.leftPin) > lineFollowerThreshold;
        rightTriggered = BoeBot.analogRead(this.rightPin) > lineFollowerThreshold;
        middleTriggered = BoeBot.analogRead(this.middlePin) > lineFollowerThreshold;
    }

    /**
     * Gives what the line follower would do to follow the line.
     * @return ServoStatus to keep following the line.
     */
    public ServoStatus getAdvice() {
        if(middleTriggered && leftTriggered && rightTriggered)
            return ServoStatus.DONT_MOVE;
        if (middleTriggered || leftTriggered || rightTriggered) {
            if (!middleTriggered) {
                if (rightTriggered) {
                    return ServoStatus.ROTATE_RIGHT;
                } else {
                    return ServoStatus.ROTATE_LEFT;
                }
            } else {
                if (rightTriggered) {
                    return ServoStatus.ROTATE_RIGHT_FORWARD;
                } else if (leftTriggered) {
                    return ServoStatus.ROTATE_LEFT_FORWARD;
                } else {
                    return ServoStatus.FORWARD;
                }
            }
        }
        return ServoStatus.FORWARD;
    }

    public Configuration getConfig() {
        return config;
    }

    public int getLeftPin() {
        return leftPin;
    }

    public int getMiddlePin() {
        return middlePin;
    }

    public int getRightPin() {
        return rightPin;
    }

    public int getLineFollowerThreshold() {
        return lineFollowerThreshold;
    }

    public boolean isLeftTriggered() {
        return leftTriggered;
    }

    public boolean isMiddleTriggered() {
        return middleTriggered;
    }

    public boolean isRightTriggered() {
        return rightTriggered;
    }
}
