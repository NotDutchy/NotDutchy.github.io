package boebot.interfaces.navigation;

import TI.BoeBot;
import TI.Timer;
import boebot.config.Configuration;
import boebot.hardware.servo.ServoStatus;
import boebot.interfaces.Driver;
import boebot.interfaces.Updateable;
import boebot.interfaces.obstacledetector.FeelerDetector;
import boebot.interfaces.obstacledetector.ObstacleDetector;
import boebot.interfaces.obstacledetector.UltraSoneDetector;

import java.awt.*;

public class RandomRouteNavigator implements Updateable, Navigation {
    private Configuration config;
    private Driver driver;
    private ObstacleDetector obstacleDetector;
    private Timer turningTimer;
    private Timer backTimer;
    private Timer timer;
    private boolean isStarted;

    /**
     * This is a navigator so that the robot will go random paths.
     * @param config of the robot
     */
    public RandomRouteNavigator(Configuration config) {
        isStarted = false;
        this.config = config;
        BoeBot.rgbSet(this.config.getModeLedPin(), Color.YELLOW);
        BoeBot.rgbShow();
    }

    /**
     * Update method for RandomRouteNavigator
     */
    @Override
    public void update() {
        if(!isStarted)
            return;
        if(!timer.timeout())
            return;
        obstacleDetector.update();
        if(turningTimer != null && turningTimer.timeout() && !obstacleDetector.isObstacleNear()) {
            this.driver.makeSameSpeed(10);
            this.driver.change(ServoStatus.FORWARD, config.getRandomRouteMaxForwardSpeed());
            turningTimer = null;
        }
        if(this.driver.getServoStatus() == ServoStatus.BACKWARDS && backTimer.timeout()) {
                this.driver.change(ServoStatus.ROTATE_RIGHT, config.getRandomRouteMaxTurningSpeed());
                this.driver.makeSameSpeed(10);
                turningTimer = new Timer(config.getRandomRouteTurningTimer());
        }
        this.driver.update();
    }

    @Override
    public void obstacleCallBack(ObstacleDetector obstacleDetector) {
        if(obstacleDetector.isFirstTime()) {
            this.driver.makeSameSpeed(-10);
        }
        this.driver.change(ServoStatus.BACKWARDS, config.getRandomRouteMaxBackwardsSpeed());
        backTimer.mark();
    }

    /**
     * This will be runned when the navigator starts, it will setup everything.
     */
    @Override
    public void start() {
        isStarted = true;
        this.config = config;
        this.driver = new Driver(config);
        //this.obstacleDetector = new FeelerDetector(this.config, this);
        this.obstacleDetector = new UltraSoneDetector(this.config.getUpperUltraSoneTrigPin(), this.config.getUpperUltraSoneEchoPin(), this, 30);
        this.driver.change(ServoStatus.FORWARD, config.getRandomRouteMaxForwardSpeed());
        this.driver.update();
        turningTimer = new Timer(config.getRandomRouteTurningTimer());
        backTimer = new Timer(config.getRandomRouteBackTimer());
        timer = new Timer (50);
    }
}
