package boebot.interfaces;

public interface Updateable {
    void update();
}
