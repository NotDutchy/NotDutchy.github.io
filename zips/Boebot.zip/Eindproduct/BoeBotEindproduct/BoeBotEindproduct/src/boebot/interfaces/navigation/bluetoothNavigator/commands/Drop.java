
package boebot.interfaces.navigation.bluetoothNavigator.commands;

import boebot.config.Configuration;
import boebot.hardware.servo.ServoStatus;
import boebot.interfaces.Gripper;
import boebot.interfaces.Driver;
import boebot.interfaces.navigation.BluetoothNavigator;
import boebot.interfaces.navigation.bluetoothNavigator.Command;

public class Drop implements Command {
    private BluetoothNavigator bluetoothNavigator;
    private Gripper gripper;

    public Drop(BluetoothNavigator bluetoothNavigator) {
        this.bluetoothNavigator = bluetoothNavigator;
        this.gripper = bluetoothNavigator.getGripper();
    }

    @Override
    public void start() {
        update();
    }

    /**
     * Opens gripper so that the object is put down on the ground.
     */

    @Override
    public void update() {
        this.gripper.open();
    }
}
