package boebot.interfaces.navigation.bluetoothNavigator.commands;

import TI.BoeBot;
import TI.Timer;
import boebot.hardware.servo.ServoStatus;
import boebot.interfaces.Driver;
import boebot.interfaces.navigation.BluetoothNavigator;
import boebot.interfaces.navigation.bluetoothNavigator.Command;

public class Left implements Command {
    private final BluetoothNavigator bluetoothNavigator;
    private boolean isMiddleLine;
    private boolean isLeftLine;
    private boolean isRightLine;
    private Timer updateTimer;
    private Timer finishTimer;

    public Left(BluetoothNavigator bluetoothNavigator) {
        this.bluetoothNavigator = bluetoothNavigator;
    }

    @Override
    public void start() {
        bluetoothNavigator.getDriver().change(ServoStatus.ROTATE_LEFT, 40, 5);
        updateTimer = new Timer(200);
        finishTimer = null;
        update();
    }

    /**
     * Timers make sure that in the beginning it won't stop rotating, after the timers are finished it'll check if
     * the middle line follower is true and the rest is false, if that's the case then the BoeBot is finished rotating.
     */

    @Override
    public void update() {
        Driver driver = bluetoothNavigator.getDriver();
        if(!updateTimer.timeout())
            return;
        if(finishTimer != null && finishTimer.timeout()) {
            driver.change(ServoStatus.DONT_MOVE, 0, 200);
            driver.makeSameSpeed();
            bluetoothNavigator.commandCallBack(this);
        } else {
            isMiddleLine = BoeBot.analogRead(bluetoothNavigator.getConfig().getMiddleLineFollowerPin()) > bluetoothNavigator.getLineFollower().getLineFollowerThreshold();
            isLeftLine = BoeBot.analogRead(bluetoothNavigator.getConfig().getLeftLineFollowerPin()) > bluetoothNavigator.getLineFollower().getLineFollowerThreshold();
            isRightLine = BoeBot.analogRead(bluetoothNavigator.getConfig().getRightLineFollowerPin()) > bluetoothNavigator.getLineFollower().getLineFollowerThreshold();

            if (isMiddleLine && !isLeftLine && !isRightLine) {
                finishTimer = new Timer(150);
            }
        }
    }
}
