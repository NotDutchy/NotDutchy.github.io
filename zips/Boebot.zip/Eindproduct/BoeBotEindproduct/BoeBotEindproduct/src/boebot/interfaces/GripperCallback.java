package boebot.interfaces;

public interface GripperCallback {
    void OnGripperOpen();
    void OnGripperClose();
}
