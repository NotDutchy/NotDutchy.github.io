package boebot.interfaces.navigation;

import TI.BoeBot;
import TI.Timer;
import boebot.config.Configuration;
import boebot.hardware.servo.ServoStatus;
import boebot.interfaces.Driver;
import boebot.interfaces.LineFollower;
import boebot.interfaces.Updateable;
import boebot.interfaces.obstacledetector.ObstacleDetector;
import boebot.interfaces.obstacledetector.UltraSoneDetector;

import javax.sound.sampled.Line;
import java.awt.*;

public class LineFollowerNavigator implements Updateable, Navigation {
    private Configuration config;
    private Driver driver;
    private Timer stopTimer;
    private Timer timer;
    private ObstacleDetector obstacleDetector;
    private boolean isStarted;
    private LineFollower lineFollower;

    public LineFollowerNavigator(Configuration config) {
        isStarted = false;
        this.config = config;
        BoeBot.rgbSet(config.getModeLedPin(), Color.WHITE);
        BoeBot.rgbShow();
    }

    /**
     * The BoeBot runs this method whenever it is set in linefollower mode. This makes it follow black/dark lines. This will only work if the user has started the program by using the start method in this class by pressing the button on the remote.
     */

    @Override
    public void update() {
        if(!isStarted)
            return;
        if (stopTimer.timeout()) {
            stopTimer.setInterval(0);
            driver.change(ServoStatus.DONT_MOVE, 0, 15);
            driver.update();
            return;
        }
        if(!timer.timeout())
            return;
        lineFollower.update();
        this.obstacleDetector.update();
        if (lineFollower.isLeftTriggered() || lineFollower.isRightTriggered() || lineFollower.isMiddleTriggered() || this.obstacleDetector.isObstacleNear()) {
            stopTimer.mark();
        }
        if(!this.obstacleDetector.isObstacleNear()) {
            ServoStatus servoStatus = lineFollower.getAdvice();
            System.out.println("Using servoStatus: " + servoStatus.toString());
            switch (servoStatus) {
                case DONT_MOVE:
                case FORWARD:
                    driver.change(ServoStatus.FORWARD, config.getRandomRouteMaxForwardSpeed(), 5);
                    driver.makeSameSpeed();
                    break;
                case BACKWARDS:
                    driver.change(servoStatus, config.getRandomRouteMaxBackwardsSpeed(), 5);
                    driver.makeSameSpeed();
                    break;
                case ROTATE_LEFT:
                case ROTATE_LEFT_BACKWARDS:
                case ROTATE_RIGHT_BACKWARDS:
                case ROTATE_LEFT_FORWARD:
                case ROTATE_RIGHT_FORWARD:
                case ROTATE_RIGHT:
                    driver.change(servoStatus, 50, 5);
                    driver.makeSameSpeed();
                    break;
            }
        } else {
            driver.change(ServoStatus.DONT_MOVE, 0, 5);
            driver.makeSameSpeed();
        }

        driver.update();
    }

    /**
     * Method that is used for detecting an obstacle in the path of the BoeBot.
     * It'll stop the BoeBot from moving by changing the servostatus.
     * @param obstacleDetector The upper ultrasone detector on our BoeBot.
     */

    @Override
    public void obstacleCallBack(ObstacleDetector obstacleDetector) {
        System.out.println("Obstacle detected");
        driver.change(ServoStatus.DONT_MOVE, 0, 50);
    }

    /**
     * This method is used when the user start the program by pressing the start navigator button on the remote.
     * It'll initialize most of the objects for the update method to work.
     */

    @Override
    public void start() {
        isStarted = true;
        lineFollower = new LineFollower(this.config);
        this.driver = new Driver(config);
        stopTimer = new Timer(2500);
        stopTimer.mark();
        timer = new Timer (50);
        this.obstacleDetector = new UltraSoneDetector(this.config.getUpperUltraSoneTrigPin(), this.config.getUpperUltraSoneEchoPin(),this, 20);
        BoeBot.rgbSet(config.getModeLedPin(), Color.WHITE);
        BoeBot.rgbShow();
    }
}
