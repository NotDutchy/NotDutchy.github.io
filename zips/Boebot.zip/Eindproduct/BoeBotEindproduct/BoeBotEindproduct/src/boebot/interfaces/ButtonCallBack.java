package boebot.interfaces;

public interface ButtonCallBack {
    void buttonCallBack(Button button);
}
