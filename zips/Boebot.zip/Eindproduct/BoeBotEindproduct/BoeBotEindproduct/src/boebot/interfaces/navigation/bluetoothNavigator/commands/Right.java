package boebot.interfaces.navigation.bluetoothNavigator.commands;

import TI.BoeBot;
import TI.Timer;
import boebot.hardware.servo.ServoStatus;
import boebot.interfaces.Driver;
import boebot.interfaces.navigation.BluetoothNavigator;
import boebot.interfaces.navigation.bluetoothNavigator.Command;

public class Right implements Command {
    private final BluetoothNavigator bluetoothNavigator;
    private boolean isMiddleLine;
    private boolean isLeftLine;
    private boolean isRightLine;
    private Timer updateTimer;
    private Timer finishTimer;

    public Right(BluetoothNavigator bluetoothNavigator) {
        this.bluetoothNavigator = bluetoothNavigator;
    }

    @Override
    public void start() {
        bluetoothNavigator.getDriver().change(ServoStatus.ROTATE_RIGHT, 40, 5);
        updateTimer = new Timer(75);
        finishTimer = null;
        update();
    }

    /**
     * Triggers the BoeBot to rotate to the right.
     */
    @Override
    public void update() {
        Driver driver = bluetoothNavigator.getDriver();
        if(!updateTimer.timeout())
            return;
        if(finishTimer != null && finishTimer.timeout()) {
            driver.change(ServoStatus.DONT_MOVE,0,200);
            driver.makeSameSpeed();
            bluetoothNavigator.commandCallBack(this);
        } else {
            isMiddleLine = BoeBot.analogRead(bluetoothNavigator.getConfig().getMiddleLineFollowerPin()) > bluetoothNavigator.getLineFollower().getLineFollowerThreshold();
            isLeftLine = BoeBot.analogRead(bluetoothNavigator.getConfig().getLeftLineFollowerPin()) > bluetoothNavigator.getLineFollower().getLineFollowerThreshold();
            isRightLine = BoeBot.analogRead(bluetoothNavigator.getConfig().getRightLineFollowerPin()) > bluetoothNavigator.getLineFollower().getLineFollowerThreshold();

            if (isMiddleLine && !isLeftLine && !isRightLine) {
                finishTimer = new Timer(50);
            }
        }
    }
}
