package boebot.config;

public class BB0117 implements Configuration {

    /*
    Config for the BB0117 robot.
     */
    public BB0117() {

    }

    @Override
    public int getLeftServoOffset() {
        return 0;
    }

    @Override
    public int getRightServoOffset() {
        return 0;
    }

    @Override
    public int getLeftServoPin() {
        return 12;
    }

    @Override
    public int getRightServoPin() {
        return 13;
    }

    @Override
    public int getGripperServoPin() {
        return 14;
    }

    @Override
    public int getDriverLeftTurningLightPin() {
        return 15;
    }

    @Override
    public int getDriverRightTurningLightPin() {
        return 0;
    }

    @Override
    public int getDriverBuzzerGoingBackwardsPin() {
        return 3;
    }

    @Override
    public int getDriverBlinkingLedTimer() {
        return 750;
    }

    @Override
    public int getIRDelayTime() {
        return 0; //TODO
    }

    @Override
    public int getIRPin() {
        return 4;
    }

    @Override
    public int getLeftWhiskerPin() {
        return 14;
    }

    @Override
    public int getRightWhiskerPin() {
        return 11;
    }

    @Override
    public int getRandomRouteTurningTimer() {
        return 2000;
    }

    @Override
    public int getRandomRouteMaxForwardSpeed() {
        return 50;
    }

    @Override
    public int getRandomRouteMaxTurningSpeed() {
        return 40;
    }

    @Override
    public int getRandomRouteBackTimer() {
        return 2000;
    }

    @Override
    public int getRandomRouteMaxBackwardsSpeed() {
        return 40;
    }

    @Override
    public int getBottomUltraSoneTrigPin() {
        return 2;
    }

    @Override
    public int getBottomUltraSoneEchoPin() {
        return 1;
    }

    @Override
    public int getUpperUltraSoneTrigPin() {
        return 6;
    }

    @Override
    public int getUpperUltraSoneEchoPin() {
        return 7;
    }

    @Override
    public int getDownUltraSoneTrigPin() {
        return 1;
    }

    @Override
    public int getDownUltraSoneEchoPin() {
        return 2;
    }

    @Override
    public int getLeftLineFollowerPin() {
        return 1;
    }

    @Override
    public int getMiddleLineFollowerPin() {
        return 2;
    }

    @Override
    public int getRightLineFollowerPin() {
        return 3;
    }

    @Override
    public int getLineFollowerThreshold() {
        return 1300;
    }

    @Override
    public int getModeLedPin() {
        return 1;
    }

    @Override
    public int getEmergencyStopPin() {
        return 0;
    }
}

