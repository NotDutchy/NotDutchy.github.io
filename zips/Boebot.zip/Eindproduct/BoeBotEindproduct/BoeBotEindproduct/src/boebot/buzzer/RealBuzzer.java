package boebot.buzzer;

import TI.BoeBot;
import TI.PinMode;

public class RealBuzzer implements Buzzer {
    private int pin;
    public RealBuzzer(int pin) {
        this.pin = pin;
        BoeBot.setMode(pin, PinMode.Output);
    }

    public void buzz(int freq) {
        BoeBot.freqOut(pin, freq, 10);
    }
}
