package boebot.buzzer;

public interface Buzzer {
    void buzz(int freq);
}
