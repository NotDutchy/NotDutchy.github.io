import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.Tab;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import jssc.SerialPortException;

import java.io.*;
import java.util.ArrayList;

public class Controls {

    private ArrayList<Character> blueToothCommands;
    private VBox commands;
    private GridPane directions;
    private BorderPane mainPane;
    private ListView<String> listView;
    private Tab controls;
    private VBox vBoxLeft;
    private HBox hBox;
    private ImageView image;

    public Controls(BoeBotUI boeBotUI) {

        mainPane = new BorderPane();
        listView = new ListView<>();
        directions = new GridPane();
        commands = new VBox(5);
        vBoxLeft = new VBox();
        hBox = new HBox();
        this.controls = new Tab("Controls");
        this.blueToothCommands = new ArrayList<>();

        /**
         * Initialising Image objects for buttons.
         */
        Image arrowRight = new Image(getClass().getResourceAsStream("/ArrowRight.png"));
        Image arrowBack = new Image(getClass().getResourceAsStream("/ArrowBack.png"));
        Image arrowLeft = new Image(getClass().getResourceAsStream("/ArrowLeft.png"));
        Image arrowForward = new Image(getClass().getResourceAsStream("/ArrowForward.png"));

        /**
         * Setting the Image objects to Background images.
         */
        BackgroundImage bImgRight = new BackgroundImage(arrowRight, BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER, BackgroundSize.DEFAULT);
        BackgroundImage bImgBack = new BackgroundImage(arrowBack, BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER, BackgroundSize.DEFAULT);
        BackgroundImage bImgLeft = new BackgroundImage(arrowLeft, BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER, BackgroundSize.DEFAULT);
        BackgroundImage bImgForward = new BackgroundImage(arrowForward, BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER, BackgroundSize.DEFAULT);

        /**
         * Settings background images to background objects.
         */
        Background bGroundRight = new Background(bImgRight);
        Background bGroundBack = new Background(bImgBack);
        Background bGroundLeft = new Background(bImgLeft);
        Background bGroundForward = new Background(bImgForward);

        Font font = Font.font("Verdana", FontWeight.BOLD, 16);

        /**
         * Creating button objects for the controls
         */
        Button openFile = new Button("Open Route");
        Button save = new Button("Save Route");
        Button forward = new Button();
        Button left = new Button();
        Button right = new Button();
        Button backwards = new Button();
        Button emergencyStop = new Button("Emergency");
        Button open = new Button("Open");
        Button close = new Button("Close");
        Button undo = new Button("Undo");
        Button remove = new Button("Remove");
        Button clear = new Button("Clear");
        Button start = new Button ("Start");

        /**
         * Setting button objects to a preferred size.
         */
        openFile.setPrefSize(100, 100);
        save.setPrefSize(100, 100);
        forward.setPrefSize(100, 100);
        left.setPrefSize(100, 100);
        right.setPrefSize(100, 100);
        backwards.setPrefSize(100, 100);
        emergencyStop.setPrefSize(150, 150);
        open.setPrefSize(100, 100);
        close.setPrefSize(100, 100);
        undo.setPrefSize(150, 150);
        remove.setPrefSize(150, 150);
        clear.setPrefSize(150, 150);
        start.setPrefSize(100,100);

        /**
         * Setting background of buttons.
         */
        openFile.setBackground(null);
        save.setBackground(null);
        right.setBackground(bGroundRight);
        backwards.setBackground(bGroundBack);
        left.setBackground(bGroundLeft);
        forward.setBackground(bGroundForward);
        close.setBackground(null);
        open.setBackground(null);

        mainPane.setPadding(new Insets(5, 5, 5, 0));
        directions.setPadding(new Insets(25));

        emergencyStop.setFont(font);
        emergencyStop.setStyle(" -fx-background-color: #d10d27; -fx-border-style: solid; ");
        start.setFont(font);
        start.setStyle(" -fx-background-color: #42f54e; ");

        /**
         * Assigning actions to the buttons, it'll add an action to the listview and a character to the arrayList. Except for the emergency button, this one is directly send.
         */
        forward.setOnAction(event -> {
            listView.getItems().add("Forward");
            this.blueToothCommands.add('w');
        });

        left.setOnAction(event -> {
            listView.getItems().add("Left");
            this.blueToothCommands.add('a');
        });

        right.setOnAction(event -> {
            listView.getItems().add("Right");
            this.blueToothCommands.add('d');
        });

        backwards.setOnAction(event -> {
            listView.getItems().add("Back");
            this.blueToothCommands.add('s');
        });

        emergencyStop.setOnAction(event -> {
            try {
                System.out.println("Emergency stop pressed!");
                boeBotUI.getPort().writeBytes("[EM]".getBytes());
            } catch (SerialPortException e) {
                e.printStackTrace();
            }
        });

        open.setOnAction(event -> {
            listView.getItems().add("Open");
            this.blueToothCommands.add('o');
        });

        close.setOnAction(event -> {
            listView.getItems().add("Close");
            this.blueToothCommands.add('c');
        });

        undo.setOnAction(event -> {
            if (listView.getItems().size() > 0) {
                listView.getItems().remove(listView.getItems().size() - 1);
            }

            if(this.blueToothCommands.size() > 0){
                this.blueToothCommands.remove(this.blueToothCommands.size() - 1);
            }
        });

        remove.setOnAction(event -> {
            if (!listView.getSelectionModel().isEmpty()) {
                listView.getItems().remove(listView.getSelectionModel().getSelectedIndex());
                listView.getSelectionModel().clearSelection();
                this.blueToothCommands.remove(listView.getSelectionModel().getSelectedIndex() + 1);
            }
        });

        clear.setOnAction(event -> {
            listView.getItems().clear();
            this.blueToothCommands.clear();
        });

        /**
         * Sends the arraylist to the BoeBot. If no COM port is selected it wont't do anything.
         */
        start.setOnAction(event -> {
            if(boeBotUI.getPort().isOpened()) {
                try {
                    System.out.println("Sending data...");
                    boeBotUI.getPort().writeBytes("[Route/".getBytes());
                    for (Character character : this.blueToothCommands) {
                        boeBotUI.getPort().writeBytes(character.toString().getBytes());
                        boeBotUI.getPort().writeBytes(",".getBytes());
                    }
                    System.out.println("Data send.");
                    boeBotUI.getPort().writeBytes("]".getBytes());
                } catch (SerialPortException e) {
                    e.printStackTrace();
                }
            }
        });

        /**
         * Saves arrayList with characters to a file.
         */
        save.setOnAction(event -> {
            FileChooser fc = new FileChooser();
            try {
                FileOutputStream fos = new FileOutputStream(fc.showSaveDialog(null));
                if(fos != null) {
                    ObjectOutputStream oos = new ObjectOutputStream(fos);
                    oos.writeObject(this.blueToothCommands);
                    oos.close();
                }
            }catch(FileNotFoundException e){
                e.printStackTrace();
            }catch(IOException e){
                e.printStackTrace();
            }
        });

        /**
         * User can open a file with a specific route to the computer.
         */
        openFile.setOnAction(event -> {
            FileChooser fc = new FileChooser();
            try {
                FileInputStream fis = new FileInputStream(fc.showOpenDialog(null));
                if(fis != null){
                    ObjectInputStream ois = new ObjectInputStream(fis);
                    blueToothCommands = (ArrayList<Character>) ois.readObject();
                }
            }catch(IOException | ClassNotFoundException e){
                e.printStackTrace();
            }

            listView.getItems().clear();
            getItemsOnListviewer();
        });

        /**
         * Assinging locations on the GUI for the buttons
         */
        vBoxLeft.getChildren().addAll(listView);
        hBox.getChildren().addAll(undo, clear, remove, emergencyStop);
        //commands.getChildren().addAll(open, close);

        directions.add(openFile, 0 ,0);
        directions.add(save, 2, 0);
        directions.add(forward, 1, 0);
        directions.add(left, 0 , 1);
        directions.add(start, 1,1);
        directions.add(right, 2, 1);
        directions.add(backwards, 1, 2);
        directions.add(open, 0,2);
        directions.add(close, 2,2);

        //mainPane.setLeft(commands);
        mainPane.setCenter(directions);
        mainPane.setRight(vBoxLeft);
        mainPane.setBottom(hBox);


        listView.getSelectionModel().getSelectedIndex();

        controls.setClosable(false);
        controls.setContent(mainPane);
    }

    /**
     * This function is used for opening a file and adding all the chars in the arraylist to the listview with the corresponding action.
     */
    private void getItemsOnListviewer(){
        for (Character charr : this.blueToothCommands) {
            if(charr.equals('w')){
                listView.getItems().add("Forward");
            }
            if(charr.equals('a')){
                listView.getItems().add("Left");
            }
            if(charr.equals('d')){
                listView.getItems().add("Right");
            }
            if(charr.equals('s')){
                listView.getItems().add("Backwards");
            }
            if(charr.equals('o')){
                listView.getItems().add("Open");
            }
            if(charr.equals('c')){
                listView.getItems().add("Close");
            }
        }
    }
    public Tab getControls() {
        return controls;
    }
}
