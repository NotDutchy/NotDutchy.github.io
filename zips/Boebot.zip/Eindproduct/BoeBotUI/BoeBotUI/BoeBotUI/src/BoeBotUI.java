import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.TabPane;
import javafx.stage.Stage;
import jssc.SerialPort;
import jssc.SerialPortException;

public class BoeBotUI extends Application {
    TabPane tabPane;
    private SerialPort port;
    private int baudrate;

    @Override
    public void start(Stage stage) throws Exception {

        /**
         * Setting a standard COM port.
         */
        port = new SerialPort("COM1");

        Controls controls = new Controls(this);
        GridControl gridControl = new GridControl();
        Settings settings = new Settings(this);
        Manual manual = new Manual();

        /**
         * Adding tabs to the tabPane.
         */
        tabPane = new TabPane(controls.getControls(), settings.getSettings(), manual.getManual());

        Scene scene = new Scene(tabPane);

        stage.setScene(scene);
        stage.setTitle("BoeBot GUI");
        stage.show();
    }

    /**
     * @param port is the port selected in Settings.java.
     * @param baudrate is the baudrate selected in Settings.java
     *
     * This function is only used in the Settings.java to select a port and baudrate.
     */
    public void setPort(SerialPort port, int baudrate) {
        this.port = port;
        this.baudrate = baudrate;
        openPort();
    }

    /**
     * Opens port, is used in the setPort function in this class.
     */
    private void openPort(){
        try {
            if(this.port.openPort()) {
                this.port.setParams(this.baudrate, 8, 1, 0);
                this.port.setFlowControlMode(SerialPort.FLOWCONTROL_RTSCTS_IN | SerialPort.FLOWCONTROL_RTSCTS_OUT);
            }
        } catch (SerialPortException e) {
            e.printStackTrace();
        }
    }


    public SerialPort getPort() {
        return port;
    }

    public static void main(String[] args) {
        launch(BoeBotUI.class);
    }
}
