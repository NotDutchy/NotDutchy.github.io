import javafx.scene.control.Tab;
import javafx.scene.control.TextArea;
import javafx.scene.layout.BorderPane;

public class Manual {

    private Tab manual;
    private BorderPane mainpane;

    public Manual() {
        this.manual = new Tab("Manual");
        this.mainpane= new BorderPane();
        this.manual.setClosable(false);

        TextArea manualText = new TextArea();
        manualText.setText("IMPORTANT: Add Jssc 2.9.4 to your project libraries to use this application!" +
                "\n\n If the project gives input must not be null error when trying to load the image files mark the res directory \nas resources root by right clicking on the package -> go down to mark directory as -> resources root" +
                "\n\nControls:\nYou can give commands with the arrow buttons, as well as the open and close button for the gripper. \nOnce you have given your commands you can press start to run the program on the BoeBot. \nYou can remove commands from the list with the buttons on the bottom. \nClear deletes the whole list.\nRemove deletes the selected action. \nYou can stop the BoeBot immediately with the Emergency button.\nYou can save your route by pressing 'Save Route'\nYou can open a route by pressing 'Open Route" +
                " \n\nSettings:\nIn settings you can change the COM port and Baudrate.\nThe standard baudrate the BoeBot uses is 115200." +
                "");


        manualText.setEditable(false);

        mainpane.setCenter(manualText);
        this.manual.setContent(mainpane);
    }

    public Tab getManual() {
        return manual;
    }

}
