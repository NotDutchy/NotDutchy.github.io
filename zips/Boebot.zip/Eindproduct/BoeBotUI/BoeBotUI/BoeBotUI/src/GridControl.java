import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.control.TextField;
import javafx.scene.layout.Background;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;

public class GridControl {

    GridPane gridPane;
    BorderPane mainPane;
    private Tab gridControl;
    private int width;
    private int height;

    /**
     * This class isn't used because there wasn't enough time. However it is a starting point for further expansion of the GUI.
     */

    public GridControl() {
        mainPane = new BorderPane();
        gridPane = new GridPane();
        this.width = 5;
        this.height = 5;
        this.gridControl = new Tab("Gridcontrol");

        TextField textField = new TextField("5");
        TextField heightField = new TextField("5");
        mainPane.setTop(new Label("Enter value for grid size."));
        mainPane.setLeft(textField);
        mainPane.setCenter(gridPane);

        textField.setOnAction(event -> {
            try {
                if (Integer.parseInt(textField.getText()) > 1 && Integer.parseInt(textField.getText()) <= 30) {
                    this.width = Integer.parseInt(textField.getText());
                    this.height = Integer.parseInt(textField.getText());
                    drawGrid();
                }
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        });

        gridControl.setClosable(false);
        gridControl.setContent(mainPane);
        drawGrid();
    }

    public Tab getGridControl() {
        return gridControl;
    }

    /**
     * Draws a 5x5 grid of button objects on the GUI.
     */
    public void drawGrid() {
        gridPane.getChildren().clear();
        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                Button button = new Button();
                button.setPrefSize(40, 40);
                button.setOnAction(event -> {
                    button.setStyle("-fx-background-color: #db1616;");
                });
                gridPane.add(button, x, y);
            }
        }
    }
}
