import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Tab;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import jssc.SerialPort;
import jssc.SerialPortList;

public class Settings {
    private Tab settings;
    private ComboBox<String> comports;
    private ComboBox<String> baudrate;
    private ComboBox<String> language;
    private BorderPane mainPane;
    private VBox vBox;
    private Button saveButton;
    private SerialPort port;
    private BoeBotUI boeBotUI;

    public Settings(BoeBotUI boeBotUI) {
        this.settings = new Tab("Settings");
        this.mainPane = new BorderPane();
        this.vBox = new VBox();
        this.comports = new ComboBox<>();
        this.baudrate = new ComboBox<>();
        this.saveButton = new Button("Save");
        this.boeBotUI = boeBotUI;

        this.mainPane.setLeft(vBox);
        this.vBox.getChildren().addAll(this.comports, this.baudrate, this.saveButton);

        checkPorts();
        setBaudrates();

        settings.setContent(this.mainPane);
        settings.setClosable(false);

        /**
         * If port and baudrate have a value then it'll save that value and set is as comport and baudrate and it'll make a connection.
         */
        saveButton.setOnAction(event -> {
            String port = "";
            int selectedBaudrate = 0;

            port = this.comports.getValue();
            selectedBaudrate = Integer.parseInt(this.baudrate.getValue().toString());

            if(port.equals("") || selectedBaudrate == 0){
                System.out.println("Not everything is selected yet!");
            }else {
                this.boeBotUI.setPort(new SerialPort(port), selectedBaudrate);
            }
        });
    }

    /**
     * Checks available ports on clients computer and adds them to combobox.
     */
    private void checkPorts() {
        String[] availablePorts = SerialPortList.getPortNames();
        for (String port : availablePorts) {
            this.comports.getItems().add(port);
        }
    }

    /**
     * Setting a baudrates and adding them to the combobox.
     */
    private void setBaudrates() {
        String availableBaudRates[] = {"1200", "2400", "4800", "19200", "38400", "57600", "115200"};
        for (String baudrates : availableBaudRates) {
            this.baudrate.getItems().add(baudrates);
        }
    }

    public Tab getSettings() {
        return settings;
    }
}
