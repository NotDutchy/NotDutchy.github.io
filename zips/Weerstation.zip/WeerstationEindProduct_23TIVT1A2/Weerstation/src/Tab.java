import com.sun.istack.internal.Nullable;
import java.util.ArrayList;

public class Tab {
    private String name;
    private ArrayList<Tab> subTabs;
    private String root;

    /**
     * @param name of the tab.
     * @param root is the directory in which this Tab is located.
     * @param subTabs ArrayList of subtabs this tab contains.
     */
    public Tab(String name, String root, ArrayList<Tab> subTabs) {
        this.name = name;
        this.subTabs = subTabs;
        this.root = root;
    }
    /**
     * @return name of the tab.
     */
    public String getName() {
        return name;
    }

    /**
     * @return ArrayList of all the subtabs.
     */
    public ArrayList<Tab> getSubTabs() {
        return subTabs;
    }

    /**
     * @return the directory in which this tab is located.
     */
    public String getRoot() {
        return root;
    }

    /**
     * Prints the name of the size and the size of the subtabs.
     * For each tab the name is printed and under it all the subtabs are printed.
     */
    public void printTab() {
        System.out.println("Tab: " + name);
        System.out.println("Sub Tabs: " + subTabs.size());
        System.out.println("Sub tabs list:");
        for(Tab tab : subTabs) {
            System.out.println(" - " + tab.name);
            for(Tab subTab : tab.getSubTabs()) {
                System.out.println("   - Tab: " + subTab.getName());
            }
        }
    }
}
