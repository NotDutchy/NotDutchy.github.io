import sun.security.rsa.RSAUtil;

import java.sql.SQLOutput;
import java.time.Duration;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalUnit;
import java.util.ArrayList;
import java.util.Arrays;

public class TabManager {
    private ArrayList<Tab> tabs;
    private int[] cursor;
    private int tabCursor;
    private ButtonManager buttonManager;
    private Period day;
    private Period days7;
    private Period days30;
    private Period days365;

    /**
     * Constructor of TabManager
     */
    public TabManager() {
        GUIBoard.clrDMDisplay();
        GUIBoard.clrAllDisplays();
        buttonManager = new ButtonManager();
        tabCursor = 0;
        cursor = new int[3];
        tabs = new ArrayList<>();
        createTabs();
        this.day = new Period(1);
        this.days7 = new Period(7);
        this.days30 = new Period(30);
        this.days365 = new Period(365);
        run();
    }

    /**
     * infinite while loop, checks button states and changes values on GUIBoard
     */
    public void run() {
        GUIBoard.drawTabs(this.tabs.size(), getCursorForTab(), 0);
        drawTabs();
        drawRoot();
        while(true) {
            if(buttonManager.isButtonToggled("LEFT_BLUE_BUTTON")) {
                int prevCursor = getCursorForTab(tabCursor);
                cursor[tabCursor] = addValue(getCursorForTab(), getTabSize(), -1);
                drawTab(tabCursor, prevCursor);
            } else if(buttonManager.isButtonToggled("RIGHT_BLUE_BUTTON")) {
                int prevCursor = getCursorForTab(tabCursor);
                cursor[tabCursor] = addValue(getCursorForTab(), getTabSize(), 1);
                drawTab(tabCursor, prevCursor);
            } else if(buttonManager.isButtonToggled("RED_BUTTON")) {
                if(tabCursor == 2) {
                    tabCursor = 0;
                } else {
                    tabCursor++;
                }
                if(getTabSize() == 0)
                    tabCursor = 0;

            } else {
                continue;
            }
            drawRoot();
            drawValues();
        }
    }

    /**
     *
     * @param cursor value of the cursor.
     * @param maxSize max value of tabs.
     * @param add amount to add to the tabs.
     * @return value of the cursor depth.
     */
    public int addValue(int cursor, int maxSize, int add) {
        if(cursor + add >= maxSize)
            return 0;
        if(cursor + add < 0)
            return maxSize-1;
        return cursor + add;
    }

    /**
     * Moves down 1 tab.
     * @param cursor Keeps track of the tab that is selected.
     * @return Cursor depth.
     */
    public int goTabDown(int cursor) {
        if(cursor + 1 > 2) {
            return 0;
        } else if(cursor + 1 < 0) {
            return 2;
        }
        return cursor + 1;
    }

    /**
     * Draws the tabs when the application stats up.
     * @param tabNumber The number of the tab.
     * @param prevCursor The previous position of the cursor.
     */
    public void drawTab(int tabNumber, int prevCursor) {
        GUIBoard.drawTabs(getTabSize(tabNumber),cursor[tabNumber],tabNumber);
        /*        if (getTabSize(goTabDown(tabNumber)) != 0 && getTabSize(goTabDown(goTabDown(tabNumber))) != getTabSize(goTabDown(goTabDown(prevCursor)))) {
            cursor[goTabDown(goTabDown(tabNumber))] = 0;
        }*/
        if(getTabSize(goTabDown(tabNumber)) != getTabSize(goTabDown(tabNumber), prevCursor)) {
            cursor[goTabDown(tabNumber)] = 0;
            System.out.println(getTabSize(goTabDown(tabNumber)));
            if(getTabSize(goTabDown(goTabDown(tabNumber))) == 0) {
                GUIBoard.clearRectangle(new Point(0,2 * 3), new Point(128,2 * 3 + 3),true);
            }
            GUIBoard.drawTabs(getTabSize(goTabDown(tabNumber)),cursor[goTabDown(tabNumber)],goTabDown(tabNumber));
        }
    }

    /**
     * Draws all the tabs, it only runs at the beginning.
     */
    public void drawTabs() {
        GUIBoard.clrDMDisplay();
        int depth = 0;
        ArrayList<Tab> branch = new ArrayList<>(this.tabs);
        while (branch.size() != 0) {
            int index = this.cursor[depth];
            GUIBoard.drawTabs(branch.size(), index, depth);
            branch = new ArrayList<>(branch.get(index).getSubTabs());
            depth++;
        }
    }

    /**
     * @return Returns the size of the tab that is currently selected by the tabCursor.
     */
    public int getTabSize() {
        return getTabSize(tabCursor);
    }

    /**
     * Determines the size of the given tab.
     * @param tab the tab that we want to know the size of.
     * @return The size of the tab. AKA the amount of tabs.
     */
    public int getTabSize(int tab) {
        if(tab == 0)
            return this.tabs.size();
        else if(tab == 1)
            return this.tabs.get(cursor[0]).getSubTabs().size();
        else
            return this.tabs.get(cursor[0]).getSubTabs().get(cursor[1]).getSubTabs().size();
    }

    /**
     * Determines the size of the given tab with the cursor.
     * @param tab The tab that we want to know the size of.
     * @param testCursor The cursor that is given with the tab.
     * @return The size of the tab. AKA the amount of tabs.
     */
    public int getTabSize(int tab, int testCursor) {
        if(tab == 0)
            return this.tabs.size();
        else if(tab == 1)
            return this.tabs.get(testCursor).getSubTabs().size();
        else
            return this.tabs.get(cursor[0]).getSubTabs().get(testCursor).getSubTabs().size();
    }

    /**
     *
     * @return cursor of the current cursor depth.
     */
    public int getCursorForTab() {
        return getCursorForTab(tabCursor);
    }

    /**
     *
     * @param testCursor value of the cursor depth
     * @return the cursor at the cursor depth
     */
    public int getCursorForTab(int testCursor) {
        return this.cursor[testCursor];
    }

    /**
     * Creates all tabs
     */
    private void createTabs() {
        addTab("Temperature", false);
        addTab("Humidity", true);
        addTab("Windsnelheid", false);
        this.tabs.add(new Tab("Windrichting", "Windrichting", new ArrayList<Tab>(Arrays.asList(
                new Tab("Huidig", "Windrichting.current", new ArrayList<>())))));

        addTab("Luchtdruk", false);
        addTab("Heat-Index", false);
        addTab("Windchill", false);
        addTab("Dewpoint", false);
        addTab("Rain rate", true);

        this.tabs.add(new Tab("Sunrise", "Sunrise", new ArrayList<>(Arrays.asList(
                new Tab("Huidig", "Sunrise" + ".current", new ArrayList<>())))));

        this.tabs.add(new Tab("Sunset", "Sunset", new ArrayList<>(Arrays.asList(
                new Tab("Huidig", "Sunset" + ".current", new ArrayList<>())))));

        this.tabs.add(new Tab("Individuele opdrachten", "Indv", new ArrayList<Tab>(Arrays.asList(
            new Tab("Langste Droogte", "Indv.Langste droogte", new ArrayList<>(Arrays.asList(
                new Tab("7 Dagen", "Indv.Langste droogte" + ".7days", new ArrayList<>()),
                new Tab("30 Dagen", "Indv.Langste droogte" + ".30days", new ArrayList<>()),
                new Tab("365 Dagen", "Indv.Langste droogte" + ".365days", new ArrayList<>())))),
            new Tab("Zomerdagen", "Indv.Zomerdagen", new ArrayList<Tab>(Arrays.asList(
                new Tab("7 Dagen", "Indv.Zomerdagen" + ".7days", new ArrayList<>()),
                new Tab("30 Dagen", "Indv.Zomerdagen" + ".30days", new ArrayList<>()),
                new Tab("365 Dagen", "Indv.Zomerdagen" + ".365days", new ArrayList<>())))),
            new Tab("Meeste regen maand", "Indv.Meeste regen maand", new ArrayList<>(
                Arrays.asList(new Tab("365 Dagen", "Indv.Meeste regen maand" + ".365days", new ArrayList<Tab>())))),
            new Tab("Dagen mist", "Indv.Dagen mist", new ArrayList<>(Arrays.asList(
                new Tab("7 Dagen", "Indv.Dagen mist" + ".7days", new ArrayList<>())))),
            new Tab("Aaneengevallen regen", "Indv.Aaneengevallen regen", new ArrayList<>(Arrays.asList(
                new Tab("7 Dagen", "Indv.Aaneengevallen regen" + ".7days", new ArrayList<>()),
                new Tab("30 Dagen", "Indv.Aaneengevallen regen" + ".30days", new ArrayList<>()),
                new Tab("365 Dagen", "Indv.Aaneengevallen regen" + ".365days", new ArrayList<>()))))))));



    }

    /**
     * adds a tab to the tabs list.
     * @param name name of the tab
     * @param root current root
     * @param mode if mode needs to be added
     */
    public void addTab(String name, String root, boolean mode) {
        this.tabs.add(new Tab(name, root, getDefaultPeriodTabs(root, mode)));
    }

    /**
     * adds a tab to the tabs list.
     * @param root current root
     * @param mode if mode needs to be added
     */
    public void addTab(String root, boolean mode) {
        this.tabs.add(new Tab(root, root, getDefaultPeriodTabs(root, mode)));
    }

    /**
     *
     * @param root of the current tab
     * @param mode if mode needs to be in default tabs
     * @return arraylist with default period tabs: huidig, 1 dag, 7 dagen, 30 dagen, 365 dagen.
     */
    public ArrayList<Tab> getDefaultPeriodTabs(String root, boolean mode) {
        ArrayList<Tab> tabs = new ArrayList<>();
        tabs.add(new Tab("Huidig", root + ".current", new ArrayList<>()));
        tabs.add(new Tab("1 Dag", root + ".1day", getDefaultTabs(root + ".1day", mode)));
        tabs.add(new Tab("7 Dagen", root + ".7days", getDefaultTabs(root + ".7days", mode)));
        tabs.add(new Tab("30 Dagen", root + ".30days", getDefaultTabs(root + ".30days", mode)));
        tabs.add(new Tab("365 Dagen", root + ".365days", getDefaultTabs(root + ".365days", mode)));
        return tabs;
    }

    /**
     *
     * @param root current root.
     * @param mode boolean if mode needs to be in default tabs.
     * @return arraylist of tabs with min, max. modus,mediaan, gemiddelde, standaard afwijking, and mode if (mode is true)
     */
    public ArrayList<Tab> getDefaultTabs(String root, boolean mode) {
        ArrayList<Tab> tabs = new ArrayList<>();
        tabs.add(new Tab("Min.", root + "." + "minimum", new ArrayList<>()));
        tabs.add(new Tab("Max.", root + "." + "maximum", new ArrayList<>()));
        if(mode)
            tabs.add(new Tab("Modus", root + "." + "mode", new ArrayList<>()));
        tabs.add(new Tab("Mediaan", root + "." + "median", new ArrayList<>()));
        tabs.add(new Tab("Gemiddelde", root + "." + "mean", new ArrayList<>()));
        tabs.add(new Tab("Standaard Afwijking", root + "." + "std deviation", new ArrayList<>()));

        return tabs;

    }

    /**
     * draws the current root of cursor
     */
    public void drawRoot() {
        GUIBoard.printString(getDeepestTab().getRoot().replaceAll("\\.", " ") + "                                  ", 1, 24);
    }

    /**
     * gets deepest tab
     * @return deepest tab
     */
    public Tab getDeepestTab() {
        if(tabCursor == 0) {
            return this.tabs.get(cursor[0]);
        } else if(tabCursor == 1) {
            return this.tabs.get(cursor[0]).getSubTabs().get(cursor[1]);
        } else if(tabCursor == 2) {
            if (cursor[0] > this.tabs.size()) {
                cursor[0] = 0;
                System.out.println("Resetted cursor 0");
            }
            if (cursor[1] > this.tabs.get(cursor[0]).getSubTabs().size()){
                cursor[1] = 0;
                System.out.println("Resetted cursor 1");
            }
            if (cursor[2] > this.tabs.get(cursor[0]).getSubTabs().get(cursor[1]).getSubTabs().size()) {
                cursor[2] = 0;
                System.out.println("Resetted cursor 2");
            }
            return this.tabs.get(cursor[0]).getSubTabs().get(cursor[1]).getSubTabs().get(cursor[2]);
        }
        return null;
    }

    /**
     * draws value of the GUIBoard based on the root.
     */
    public void drawValues() {
        GUIBoard.clrAllDisplays();
        GUIBoard.clearRectangle(new Point(1,16), new Point(128,23),true);
        if(tabCursor >= 1) {
            String[] rootSplitted = getDeepestTab().getRoot().split("\\.");
            if(!rootSplitted[1].equalsIgnoreCase("current") && rootSplitted.length < 3) {
                return;
            }
            Period period = getPeriod(rootSplitted[1]);
            if(period.getMeasurementsSize() == 0) {
                int[] errorValues = {0x179, 0x150, 0x150, 0x15C, 0x150};
                ArrayList<Integer> address = GUIBoard.upperCounter;
                int i = address.size()-1;
                for (int errorValue : errorValues) {
                    IO.writeShort(address.get(i), errorValue);
                    i--;
                }
                return;
            }
            switch(rootSplitted[0]) {
                case "Temperature":
                    GUIBoard.printString("Inside         ^         Outside",1,16);
                    drawValue("outsidetemp", rootSplitted, 1, GUIBoard.rightUnderCounters);
                    drawValue("insidetemp", rootSplitted, 1, GUIBoard.leftUnderCounters);
                    break;
                case "Humidity":
                    GUIBoard.printString("Inside         ^         Outside",1,16);
                    drawValue("outsidehum", rootSplitted, 0, GUIBoard.rightUnderCounters);
                    drawValue("insidehum", rootSplitted, 0, GUIBoard.leftUnderCounters);
                    break;
                case "Windsnelheid":
                    drawValue("windspeed", rootSplitted, 1, GUIBoard.upperCounter);
                    break;
                case "Luchtdruk":
                    drawValue("barometer", rootSplitted, 0, GUIBoard.upperCounter);
                    break;
                case "Heat-Index":
                    drawValue("heatindex", rootSplitted, 1, GUIBoard.upperCounter);
                    break;
                case "Windchill":
                    drawValue("windchill", rootSplitted, 1, GUIBoard.upperCounter);
                    break;
                case "Dewpoint":
                    drawValue("dewpoint", rootSplitted, 1, GUIBoard.upperCounter);
                    break;
                case "Rain rate":
                    drawValue("rainrate", rootSplitted, 0, GUIBoard.upperCounter);
                    break;
                case "Windrichting":
                    GUIBoard.printString(getPeriod(rootSplitted[1]).getLatestValidMeasurement().getValue("winddir") + "°",1,16);
                    break;
                case "Indv":
                    if(rootSplitted.length == 3) {
                        period = getPeriod(rootSplitted[2]);
                        switch (rootSplitted[1]) {
                            case "Langste droogte":
                                Period langsteDroogte = period.longestDraught(10);
                                GUIBoard.printString("Begin " + langsteDroogte.getBeginPeriod() + " tot " + langsteDroogte.getEndPeriod(),1,16);
                                break;
                            case "Zomerdagen":
                                Period summerDays = period.summerDays();
                                if(summerDays == null) {
                                    GUIBoard.printString("Geen Zomerdagen in periode",1,16);
                                } else
                                    GUIBoard.printString("Begin " + summerDays.getBeginPeriod() + " tot " + summerDays.getEndPeriod(),1,16);
                                break;
                            case "Meeste regen maand":
                                GUIBoard.printString(period.monthWithMostRainRate(),1,16);
                                break;
                            case "Dagen mist":
                                ArrayList<LocalDate> dates = period.getChanceOfFog();
                                String display = "";
                                for(LocalDate localDate : dates) {
                                    display += " " + localDate.getDayOfWeek().toString().substring(0,2);
                                }
                                GUIBoard.printString(display,1,16);
                                break;
                            case "Aaneengevallen regen":
                                GUIBoard.displayDouble(period.getMaxFallenRainConsecutive(),1, GUIBoard.upperCounter);
                                break;
                        }
                    }
                    break;
                case "Sunset":
                case "Sunrise":
                    period = getPeriod(rootSplitted[1]);
                    if(period.getMeasurementsSize() == 0) {
                        GUIBoard.printString(rootSplitted[0] +  " Onbekend",1,16);
                    }
                    Measurement m = period.getLatestValidMeasurement();
                    GUIBoard.printString(rootSplitted[0] + " " + m.getTime(rootSplitted[0]),1,16);
                    break;
            }
        }
    }

    /**
     *
     * @param value String of what values to get from measurements in period. Example outsideTemp
     * @param rootSplitted array of the root split at dots.
     * @param roundingPower amount to round.
     * @param address arraylist of addresses to draw the value. Needs to be in order.
     */
    public void drawValue(String value, String[] rootSplitted, int roundingPower, ArrayList<Integer> address) {
        Period period = getPeriod(rootSplitted[1]);
        if(rootSplitted.length > 2) {
            GUIBoard.displayDouble(getValue(period, rootSplitted[2], value),roundingPower, address);
        } else {
            if(rootSplitted[1].equalsIgnoreCase("current")) {
                GUIBoard.displayDouble(period.getLatestValidMeasurement().getValue(value),roundingPower, address);
            }
        }
    }

    /**
     *
     * @param period period
     * @param operator String of what to do with the period. Example minimum, maximum, mode etc
     * @param value String of what values to get from measurements in period. Example outsideTemp
     * @return value to get from operator and value
     */
    public Double getValue(Period period, String operator, String value) {
        switch(operator) {
            case "minimum":
                return period.getLowest(value);
            case "maximum":
                return period.getHighest(value);
            case "mode":
                return period.calculateMode(value).get(0);
            case "median":
                return period.calculateMedian(value);
            case "mean":
                return period.calculateMean(value);
            case "std deviation":
                return period.calculateStandardDeviation(value);
        }
        return 0.0;
    }

    /**
     *
     * @param per string of the period to return
     * @return an period based on per.
     */
    public Period getPeriod(String per) {
        switch(per) {
            case "1day":
                return day;
            case "7days":
                return days7;
            case "30days":
                return days30;
            case "365days":
                return days365;
            default:
                return new Period();
        }
    }
}
