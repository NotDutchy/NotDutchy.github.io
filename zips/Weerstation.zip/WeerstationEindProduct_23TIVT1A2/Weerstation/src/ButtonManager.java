import java.util.ArrayList;
import java.util.Arrays;

public class ButtonManager {
    private ArrayList<Button> buttons;

    /**
     * Creates the object ButtonManager, so we can manipulate the displays with the buttons.
     */
    public ButtonManager() {
        buttons = new ArrayList<>(Arrays.asList(new Button("RED_BUTTON",0x80), new Button("LEFT_BLUE_BUTTON", 0x90), new Button("RIGHT_BLUE_BUTTON", 0x100)));
    }

    /**
     * Checks if the state of the button object has changed.
     * @param buttonName name of the button.
     * @return true if the state has changed, false if the state is the same.
     */
    public boolean isButtonToggled(String buttonName) {
        for(Button button : buttons) {
            if(button.getName().equalsIgnoreCase(buttonName)) {
                return button.isToggled();
            }
        }
        return false;
    }


}
