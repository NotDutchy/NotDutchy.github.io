public class Button {
    private int address;
    private String name;
    private boolean previousState;

    /**
     * Constructor of Button
     * @param name of the button.
     * @param address of the button.
     */
    public Button(String name, int address) {
        this.name = name;
        this.address = address;
        this.previousState = readState();
    }


    /**
     * checks if the current state is the same as the previous state of the button.
     * @return true or false if the button is toggled
     */
    public boolean isToggled() {
        if(readState() != previousState) {
            previousState = readState();
            return true;
        }
        return false;
    }

    /**
     * @return if the button is on or off.
     */
    public boolean readState() {
        return IO.readShort(address) != 0;
    }

    /**
     * @return the name of the button.
     */
    public String getName() {
        return this.name;
    }
}
