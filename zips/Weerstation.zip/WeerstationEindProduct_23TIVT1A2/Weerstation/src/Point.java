public class Point {
    private double x;
    private double y;

    /**
     * Constructor for the point objects used to draw on the Dotmatrixdisplay.
     * @param x sets the x-coordinate.
     * @param y sets the y-coordinate.
     */
    public Point(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public double getX() {
        return this.x;
    }

    public double getY() {
        return this.y;
    }

    public void setX(double x) {
        this.x = x;
    }

    public void setY(double y) {
        this.y = y;
    }

    /**
     * Draws the actual point on the Dotmatrixdisplay.
     */
    public void draw() {
        if(this.x >= 0 && this.x < 128 && this.y >= 0 && this.y < 32) {
            IO.writeShort(0x42, (1 << 12) | ( (int) this.x << 5) | (int) this.y);
        }
    }

    /**
     * Creates a copy of an existing point so we can manipulate the point without the actual point changing values.
     * @return a copy of an already existing point.
     */
    public Point copy() {
        return new Point(this.x, this.y);
    }

    /**
     * Clears the point on the Dotmatrix display this way the point wont light up on the display.
     */
    public void clear() {
        if(this.x >= 0 && this.x < 128 && this.y >= 0 && this.y < 32) {
            IO.writeShort(0x42,  ( (int) this.x << 5) | (int) this.y);
        }
    }
}
