import java.util.ArrayList;
import java.util.Arrays;

public class GUIBoard {
    public static ArrayList<Integer> upperCounter = new ArrayList<>(Arrays.asList(0x10, 0x12, 0x14, 0x16, 0x18));
    public static ArrayList<Integer> rightUnderCounters = new ArrayList<>(Arrays.asList(0x30, 0x32, 0x34));
    public static ArrayList<Integer> leftUnderCounters = new ArrayList<>(Arrays.asList(0x20, 0x22, 0x24));


    /**
     * Clears all seven-segment displays and the dot-matrix display.
     */
    public static void clrAllDisplays() {
        clrDisplay(leftUnderCounters);
        clrDisplay(rightUnderCounters);
        clrDisplay(upperCounter);
    }

    /**
     * Displays a double on the top display rounding it in the process.
     *
     * @param value         the number to display
     * @param roundingPower the amount of decimals to round to
     */
    public static void displayDouble(double value, int roundingPower, ArrayList<Integer> values) {
        //values 0-9 converted to 7-segment including the decimal point
        int[] altValues = {0xBF, 0x86, 0xDB, 0xCF, 0xE6, 0xED, 0xFD, 0x87, 0xFF, 0xEF};
        clrDisplay(upperCounter);
        boolean negative = (value < 0);
        value = Math.abs(value);
        int number = (int) Math.round(value * Math.pow(10, roundingPower));
        int i = 0;
        for (int address : values) {
            if (i != 0 && i == roundingPower) {
                //digit with decimal point (if rounding to integer not present)
                IO.writeShort(address, 0x100 | altValues[number % 10]);
            } else {
                //regular digit
                IO.writeShort(address, number % 10);
            }
            number /= 10;
            //assuring there is in fact a 0 before a decimal point if less than 1
            if (number == 0 && i >= roundingPower) {
                if (negative) {
                    IO.writeShort(address + 2, 0x140);
                }
                break;
            }
            i++;
        }
    }

    /**
     * Clears the displays given in the ArrayList.
     *
     * @param values ArrayList with display addresses
     */
    public static void clrDisplay(ArrayList<Integer> values) {
        for (int address : values) {
            IO.writeShort(address, 0x100);
        }
    }

    /**
     * Draws a point given the bounding positions on the screen
     *
     * @param p point to draw
     * @param minX the x-position of the left edge
     * @param maxX the x-position of the right edge
     * @param minY the y-position of the bottom edge
     * @param maxY the y-position of the top edge
     */
    public static void drawTransformed(Point p, double minX, double maxX, double minY, double maxY) {
        // reduce the coordinates to be between 0 and 1
        double screenX = (p.getX() - minX) / (maxX - minX);
        double screenY = (p.getY() - minY) / (maxY - minY);
        // multiply the x and y to fit the screen size
        p.setX(Math.round(screenX * 128));
        p.setY(32 - (int) Math.round(screenY * 32));
        p.draw();
    }

    /**
     * Draws points on the dot-matrix display.
     *
     * @param points ArrayList with points to draw.
     */
    public static void drawPoints(ArrayList<Point> points) {
        clrDMDisplay();
        double minX = points.get(0).getX();
        double maxX = points.get(0).getX();
        double minY = points.get(0).getY();
        double maxY = points.get(0).getY();
        for (Point p : points) {
            if (p.getX() < minX) {
                minX = p.getX();
            }
            if (p.getX() > maxX) {
                maxX = p.getX();
            }
            if (p.getY() < minY) {
                minY = p.getY();
            }
            if (p.getY() > maxY) {
                maxY = p.getY();
            }

        }
        System.out.println("minX: " + minX + " maxX: " + maxX + " minY: " + minY + " maxY: " + maxY);
        for (double i = minX; i <= maxX; i += (maxX - minX) / 128) { // x-as
            drawTransformed(new Point(i, 0), minX, maxX, minY, maxY);
        }
        for (double i = minY; i <= maxY; i += (maxY - minY) / 32) { // y-as
            drawTransformed(new Point(0, i), minX, maxX, minY, maxY);
        }
        for (Point p : points) { // all points
            drawTransformed(p, minX, maxX, minY, maxY);
        }
    }

    /**
     * Prints a string on the dot-matrix display.
     *
     * @param s the string to print.
     */
    public static void drawString(String s) {
        for (char ch : s.toCharArray()) {
            IO.writeShort(0x40, ch);
        }
    }

    /**
     * Prints a character with the top-left corner at a given position.
     *
     * @param character the character to print
     * @param x the x-position of the top-left corner
     * @param y the y-position of the top-left corner
     */
    private static void printChar(char character, int x, int y) {
        char[] characters = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '.', ',', '!', ':', '+', '-', '/', '*', '°', '^', ' '};
        // octal because the font is 3px wide and stored in binary
        int[] configurations = {00055752, 00065756, 00034443, 00065556, 00074647, 00044647, 00075547, 00055755, 00072227, 00075113, 00055655, 00074444, 00055777, 00055557, 00075557, 00044757, 00077557, 00055657, 00071747, 00022227, 00075555, 00025555, 00077755, 00055255, 00022255, 00074217, 00075300, 00075744, 00074700, 00075711, 00076700, 00044643, 07175700, 00055744, 00072702, 07111301, 00056544, 00072226, 00057700, 00055600, 00075700, 04475700, 01175700, 00044700, 00062300, 00074644, 00035500, 00025500, 00077500, 00052500, 06135500, 00032600, 00065553, 00072262, 00074216, 00061316, 00011755, 00061747, 00075747, 00011117, 00065753, 00071757, 00020000, 00022000, 00020222, 00020020, 00002720, 00000700, 00044211, 00000727, 00000757, 00000052, 00000000};
        // fill the entire space with a "no match" character in case no match occurs
        int display = 00077777;
        for (int i = 0; i < characters.length; i++)
            if (characters[i] == character) {
                display = configurations[i];
                break;
            }
        //to make sure a character does not go out of bounds
        if (x < 0 || x > 125 || y < 0 || y > 25)
            return;
        for (int yPos = 0; yPos < 7; yPos++)
            for (int xPos = 2; xPos >= 0; xPos--) {
                IO.writeShort(0x42, ((display & 1) << 12) | ((xPos + x) << 5) | (yPos + y));
                display >>= 1;
            }
    }

    /**
     * Prints a string with the top-left corner at a given position
     *
     * @param string the string to print
     * @param x the x-position of the top-left corner
     * @param y the y-position of the top-left corner
     */
    public static void printString(String string, int x, int y) {
        int xPos = x;
        int yPos = y;
        for (char character : string.toCharArray()) {
            if (character == '\n') {
                xPos = x;
                yPos += 8;
                continue;
            }
            printChar(character, xPos, yPos);
            xPos += 4;
        }
    }

    /**
     * Clears the dot-matrix display.
     */
    public static void clrDMDisplay() {
        IO.writeShort(0x40, 0xFE);
        IO.writeShort(0x40, 0x01);
    }

    /**
     * Draws the tabs.
     * @param amount The amount of tabs that should be drawn.
     * @param selected This parameter is used to determine the tab that is currently selected.
     * @param offset THis value is used to determine how many rows of tabs are nested inside the selected tab.
     */
    public static void drawTabs(int amount, int selected, int offset) {
        if(amount == 0)
            return;
        int x = 128;
        int y = 32;
        int h = 3;
        offset *= h;
        int vSeparators = amount - 1;
        int space = (x - vSeparators) / amount;
        int leftovers = (x - vSeparators) % amount;
        int xPos = -1;
        clearTab(new Point(0, offset), new Point(x - 1, offset + h - 1), true);
        //clearRectangle(new Point(0, offset), new Point(x - 1, offset + h - 1), true); // not necessary using clear Tab
        for (int i = 0; i <= vSeparators; i++) {
            if (xPos != -1) {
                drawOrthogonalLine(new Point(xPos, offset), new Point(xPos, offset + h - 2));
            }
            if (i == selected) {
                drawRectangle(new Point(xPos + 1, offset), new Point(xPos + space + leftovers, offset + h - 2), true);
                xPos += leftovers;
            }
            xPos += space + 1;
        }
        drawOrthogonalLine(new Point(0, offset + h - 1), new Point(x, offset + h - 1));
    }

    /**
     * Draws a horizontal or vertical line between two points.
     *
     * @param point first point
     * @param point2 second point
     */
    public static void drawOrthogonalLine(Point point, Point point2) {
        point.draw();
        while (point.getX() != point2.getX() || point.getY() != point2.getY()) {
            setXAndYofPoints(point, point2);
            point.draw();
        }
    }

    /**
     *
     * Add a value to point to get closer to point2.
     * @param point to add values to
     * @param point2 end point
     */
    private static void setXAndYofPoints(Point point, Point point2) {
        if (point.getX() != point2.getX()) {
            point.setX(point.getX() + (point2.getX() - point.getX()) / Math.abs(point2.getX() - point.getX()));
        } else if (point.getY() != point2.getY()) {
            point.setY(point.getY() + (point2.getY() - point.getY()) / Math.abs(point2.getY() - point.getY()));
        }
    }

    /**
     * Clears a horizontal or vertical line between two points.
     *
     * @param point first point
     * @param point2 second point
     */
    public static void clearOrthogonalLine(Point point, Point point2) {
        point.clear();
        while (point.getX() != point2.getX() || point.getY() != point2.getY()) {
            setXAndYofPoints(point, point2);
            point.clear();

        }
    }

    /**
     * Draws an unfilled or filled rectangle with two given opposite corner points. e.g. top left point and bottom right point.
     *
     * @param point first corner point
     * @param point2 second corner point
     * @param fill filled = true, unfilled = false
     */
    public static void drawRectangle(Point point, Point point2, boolean fill) {
        drawOrthogonalLine(point.copy(), point2);
        drawOrthogonalLine(point2.copy(), point);
        if (!fill) return;
        while (point.getX() != point2.getX()) {
            point.setX(point.getX() + (point2.getX() - point.getX()) / Math.abs(point2.getX() - point.getX()));
            Point p = point2.copy();
            p.setX(point.getX());
            drawOrthogonalLine(p, point);
        }
    }

    /**
     * Clears an unfilled or filled rectangle with two given opposite corner points. e.g. top left point and bottom right point
     *
     * @param point first corner point
     * @param point2 second corner point
     * @param fill filled = true, unfilled= false
     */
    public static void clearRectangle(Point point, Point point2, boolean fill) {
        clearOrthogonalLine(point.copy(), point2);
        clearOrthogonalLine(point2.copy(), point);
        if (!fill) return;
        while (point.getX() != point2.getX()) {
            point.setX(point.getX() + (point2.getX() - point.getX()) / Math.abs(point2.getX() - point.getX()));
            Point p = point2.copy();
            p.setX(point.getX());
            clearOrthogonalLine(p, point);
        }
    }

    /**
     * Clears the inside of a tab without clearing the borders, with two given opposite corner points. e.g. top left point and bottom right point
     *
     * @param point first corner point
     * @param point2 second corner point
     * @param fill filled = true, unfilled= false
     */
    public static void clearTab(Point point, Point point2, boolean fill) {
        point2.setY(point2.getY() - 1);
        clearRectangle(point, point2, true);
    }
}