import java.time.LocalDateTime;
import java.time.ZoneId;

public class Measurement {
    private String stationId;
    private LocalDateTime dateStamp;
    private double barometer;
    private double insideTemp;
    private int insideHum;
    private double outsideTemp;
    private double windSpeed;
    private double avgWindSpeed;
    private int windDir;
    private int outsideHum;
    private double rainRate;
    private double UVLevel;
    private int solarRad;
    private double battLevel;
    private String sunrise;
    private String sunset;
    private double windChill;
    private double heatIndex;
    private double dewPoint;

    //converts every piece of data from rawMeasurements to the appropriate units using ConvertMeasure.
    public Measurement(RawMeasurement rawMeasurement) {
        this.stationId = rawMeasurement.getStationId();
        this.dateStamp = rawMeasurement.getDateStamp();
        this.barometer = ConvertMeasure.airPressure(rawMeasurement.getBarometer());
        this.insideTemp = ConvertMeasure.temperature(rawMeasurement.getInsideTemp());
        this.insideHum = ConvertMeasure.humidity(rawMeasurement.getInsideHum());
        this.outsideTemp = ConvertMeasure.temperature(rawMeasurement.getOutsideTemp());
        this.windSpeed = ConvertMeasure.windSpeed(rawMeasurement.getWindSpeed());
        this.avgWindSpeed = ConvertMeasure.windSpeed(rawMeasurement.getAvgWindSpeed());
        this.windDir = ConvertMeasure.windDirection(rawMeasurement.getWindDir());
        this.outsideHum = ConvertMeasure.humidity(rawMeasurement.getOutsideHum());
        this.rainRate = ConvertMeasure.rainMeter(rawMeasurement.getRainRate());
        this.UVLevel = ConvertMeasure.uvIndex(rawMeasurement.getUVLevel());
        this.solarRad = rawMeasurement.getSolarRad();
        this.battLevel = ConvertMeasure.batteryLevel(rawMeasurement.getBattLevel());
        this.sunrise = ConvertMeasure.time(rawMeasurement.getSunrise());
        this.sunset = ConvertMeasure.time(rawMeasurement.getSunset());
        this.windChill = ConvertMeasure.windChill(this.outsideTemp, this.windSpeed);
        this.heatIndex = ConvertMeasure.heatIndex(this.outsideTemp, this.outsideHum);
        this.dewPoint = ConvertMeasure.dewPoint(this.outsideTemp, this.outsideHum);
    }

    /**
     * gets the station ID of the station the measurement is from
     * @return the station ID of the station the measurement is from
     */
    public String getStationId() {
        return stationId;
    }

    /**
     * gets the date stamp of the measurement
     * @return the date stamp of the measurement
     */
    public LocalDateTime getDateStamp() {
        return dateStamp;
    }

    /**
     * gets the air pressure of the measurement
     * @return the air pressure of the measurement
     */
    public double getBarometer() {
        return barometer;
    }

    /**
     * gets the inside temperature of the measurement
     * @return the inside temperature of the measurement
     */
    public double getInsideTemp() {
        return insideTemp;
    }

    /**
     * gets the inside humidity of the measurement
     * @return the inside humidity of the measurement
     */
    public int getInsideHum() {
        return insideHum;
    }

    /**
     * gets the outside temperature of the measurement
     * @return the outside temperature of the measurement
     */
    public double getOutsideTemp() {
        return outsideTemp;
    }

    /**
     * gets the wind speed of the measurement
     * @return the wind speed of the measurement
     */
    public double getWindSpeed() {
        return windSpeed;
    }

    /**
     * gets the average wind speed of the measurement
     * @return the average wind speed of the measurement
     */
    public double getAvgWindSpeed() {
        return avgWindSpeed;
    }

    /**
     * gets the wind direction of the measurement
     * @return the wind direction of the measurement
     */
    public int getWindDir() {
        return windDir;
    }

    /**
     * gets the outside humidity of the measurement
     * @return the outside humidity of the measurement
     */
    public int getOutsideHum() {
        return outsideHum;
    }

    /**
     * gets the rain rate of the measurement
     * @return the rain rate of the measurement
     */
    public double getRainRate() {
        return rainRate;
    }

    /**
     * gets the UV level of the measurement
     * @return the UV level of the measurement
     */
    public double getUVLevel() {
        return UVLevel;
    }

    /**
     * gets the solar radiation of the measurement
     * @return the solar radiation of the measurement
     */
    public int getSolarRad() {
        return solarRad;
    }

    /**
     * gets the battery level of the weather station
     * @return the battery level of the weather station
     */
    public double getBattLevel() {
        return battLevel;
    }

    /**
     * gets the time of sunrise of the day of the measurement
     * @return the time of sunrise of the day of the measurement
     */
    public String getSunrise() {
        return sunrise;
    }

    /**
     * gets the time of sunset of the day of the measurement
     * @return the time of sunset of the day of the measurement
     */
    public String getSunset() {
        return sunset;
    }

    /**
     * gets the wind chill of the measurement
     * @return the wind chill of the measurement
     */
    public double getWindChill() {
        return windChill;
    }

    /**
     * gets the heat index of the measurement
     * @return the heat index of the measurement
     */
    public double getHeatIndex() {
        return heatIndex;
    }

    /**
     * gets the dew point of the measurement
     * @return the dew point of the measurement
     */
    public double getDewPoint() {
        return dewPoint;
    }

    /**
     * determines whether the air pressure is valid
     * @return true if the air pressure is valid
     */
    public boolean isValidPressure() {
        if (barometer < 900 || barometer > 1100)
            return false;
        else
            return true;
    }

    /**
     * determines whether the temperature is valid
     * @return true if the temperature is valid
     */
    public boolean isValidTemperature() {
        if (outsideTemp < -20 || outsideTemp > 50 || insideTemp < -20 || insideTemp > 50)
            return false;
        else
            return true;
    }

    /**
     * determines whether the wind speed and direction are valid
     * @return true if the wind data is valid
     */
    public boolean isValidWind() {
        if (windSpeed < 0 || windSpeed > 200 || avgWindSpeed < 0 || avgWindSpeed > 200 || windDir < 0 || windDir > 360)
            return false;
        else
            return true;
    }

    /**
     * determines whether the humidity is valid
     * @return true if the humidity is valid
     */
    public boolean isValidHumidity() {
        if (outsideHum < 0 || outsideHum > 100 || insideHum < 0 || insideHum > 100)
            return false;
        else
            return true;
    }

    /**
     * determines whether the rain rate is valid
     * @return true if the rain rate is valid
     */
    public boolean isValidRainRate() {
        if (rainRate < 0 || rainRate > 250)
            return false;
        else
            return true;
    }

    /**
     * determines whether the solar data is valid
     * @return true if the solar data is valid
     */
    public boolean isValidSolar() {
        if (solarRad < 0 || solarRad > 2000 || UVLevel < 0 || UVLevel > 11)
            return false;
        else
            return true;
    }

    /**
     * retrieves one of the values given a parameter to indicate which
     * @param type the value to retrieve
     * @return the value corresponding to the given parameter
     */
    public double getValue(String type) {
        type = type.toLowerCase();
        switch (type) {
            case "outsidetemp":
                return getOutsideTemp();
            case "insidetemp":
                return getInsideTemp();
            case "outsidehum":
                return getOutsideHum();
            case "insidehum":
                return getInsideHum();
            case "barometer":
                return getBarometer();
            case "rainrate":
                return getRainRate();
            case "winddir":
                return (double) getWindDir();
            case "windspeed":
                return getWindSpeed();
            case "windchill":
                return getWindChill();
            case "dewpoint":
                return getDewPoint();
            case "battlevel":
                return getBattLevel();
            case "avgwindspeed":
                return getAvgWindSpeed();
            case "solarrad":
                return (double) getSolarRad();
            case "uvlevel":
                return getUVLevel();
            case "heatindex":
                return getHeatIndex();
        }
        return 0;
    }

    public String getTime(String type) {
        if(type.equalsIgnoreCase("Sunrise")) {
            return getSunrise();
        } else if(type.equalsIgnoreCase("Sunset")) {
            return getSunset();
        }
        return "Geen datum";
    }

    @Override
    public String toString() {
        return "Measurement:" +
                "\nstationId = '" + stationId + '\'' +
                "\ndateStamp = " + dateStamp.atOffset(ZoneId.of("Europe/Amsterdam").getRules().getOffset(dateStamp)) +
                "\nbarometer = " + ConvertMeasure.round(barometer, "0") +
                "\ninsideTemp = " + ConvertMeasure.round(insideTemp, "0.0") +
                "\ninsideHum = " + insideHum +
                "\noutsideTemp = " + ConvertMeasure.round(outsideTemp, "0.0") +
                "\nwindSpeed = " + ConvertMeasure.round(windSpeed, "0.0") +
                "\navgWindSpeed = " + ConvertMeasure.round(avgWindSpeed, "0.0") +
                "\nwindDir = " + windDir +
                "\noutsideHum = " + outsideHum +
                "\nrainRate = " + ConvertMeasure.round(rainRate, "0") +
                "\nUVLevel = " + ConvertMeasure.round(UVLevel, "0.0") +
                "\nsolarRad = " + solarRad +
                "\nbattLevel = " + ConvertMeasure.round(battLevel, "0.00") +
                "\nwindChill = " + ConvertMeasure.round(windChill, "0.0") +
                "\nheatIndex = " + ConvertMeasure.round(heatIndex, "0.0") +
                "\ndewPoint = " + ConvertMeasure.round(dewPoint, "0.0");
    }

    /**
     * prints all valid elements of a measurement
     */
    public void printValidMeasures() {
        String s = "Measurement:\n - stationId: " + stationId + "\n - dateStamp: " + dateStamp.atOffset(ZoneId.of("Europe/Amsterdam").getRules().getOffset(dateStamp)); //this will print the date in UTC+0 with the timezone offset appended
        if(isValidPressure()) s += "\n - barometer: " + ConvertMeasure.round(barometer, "0");
        if(isValidTemperature()) s += "\n - insideTemp: " + ConvertMeasure.round(insideTemp, "0.0") + "\n - outsideTemp: " + ConvertMeasure.round(outsideTemp, "0.0");
        if(isValidHumidity()) {
            s += "\n - insideHum: " + insideHum;
            s += "\n - outsideHum: " + outsideHum;
        }
        if(isValidRainRate()) {
            s += "\n - rainRate: " + ConvertMeasure.round(rainRate, "0");
        }
        if(isValidSolar()) {
            s += "\n - solarRad: " + solarRad;
            s += "\n - UVLevel: " + ConvertMeasure.round(UVLevel, "0");
        }
        if(isValidWind()) {
            s += "\n - windSpeed: " + ConvertMeasure.round(windSpeed, "0.0");
            s += "\n - avgWindSpeed: " + ConvertMeasure.round(avgWindSpeed, "0.0");
            s += "\n - windDir: " + windDir;
            s += "\n - windChill: " + ConvertMeasure.round(windChill, "0.0");
        }
        s += "\n - sunrise: " + sunrise;
        s += "\n - sunset: " + sunset;
        s += "\n - battlevel: " + ConvertMeasure.round(battLevel, "0.00");
        if(isValidHumidity() && isValidTemperature()) {
            s += "\n - heatIndex: " + ConvertMeasure.round(heatIndex, "0.0");
            s += "\n - dewPoint: " + ConvertMeasure.round(dewPoint, "0.0");
        }
        System.out.println(s);
    }

    /**
     * determines whether the measurement as a whole is valid
     * @return true if all data is valid
     */
    public boolean isValid() {
        return isValidTemperature() && isValidHumidity() && isValidWind() && isValidSolar() && isValidRainRate() && isValidPressure();
    }
}
