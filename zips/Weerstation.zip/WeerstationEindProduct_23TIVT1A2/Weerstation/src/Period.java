import java.lang.reflect.Array;
import java.time.*;
import java.time.temporal.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;

/**
 * A class to contain a period of time
 *
 * @author Johan Talboom
 * @version 2.0
 */
public class Period {
    private LocalDate beginPeriod;
    private LocalDate endPeriod;
    private ArrayList<Measurement> measurements;

    /**
     * default constructor, sets the period to today
     */
    public Period() {
        beginPeriod = LocalDate.now();
        endPeriod = LocalDate.now();
        getMeasurements();
    }

    public Period(LocalDate beginPeriod, LocalDate endPeriod) {
        this.beginPeriod = beginPeriod;
        this.endPeriod = endPeriod;
        getMeasurements();
    }

    public Period(LocalDate beginPeriod) {
        this.beginPeriod = beginPeriod;
        this.endPeriod = LocalDate.now();
        getMeasurements();
    }

    public Period(int days) {
        this.beginPeriod = LocalDate.now().minus(java.time.Period.ofDays(days));
        this.endPeriod = LocalDate.now();
        getMeasurements();
    }

    /**
     * Simple setter for start of period
     */
    public void setStart(int year, int month, int day) {
        beginPeriod = LocalDate.of(year, month, day);
    }

    /**
     * simple setter for end of period
     */
    public void setEnd(int year, int month, int day) {
        endPeriod = LocalDate.of(year, month, day);
    }

    /**
     * alternative setter for start of period
     *
     * @param beginPeriod
     */
    public void setStart(LocalDate beginPeriod) {
        this.beginPeriod = beginPeriod;
    }

    /**
     * alternative setter for end of period
     *
     * @param endPeriod
     */
    public void setEnd(LocalDate endPeriod) {
        this.endPeriod = endPeriod;
    }

    /**
     * calculates the number of days in the period
     */
    public long numberOfDays() {
        return ChronoUnit.DAYS.between(beginPeriod, endPeriod);
    }


    /**
     * gets all raw measurements of this period from the database
     *
     * @return a list of raw measurements
     */
    public ArrayList<RawMeasurement> getRawMeasurements() {
        return DatabaseConnection.getMeasurementsBetween(LocalDateTime.of(beginPeriod, LocalTime.of(0, 1)), LocalDateTime.of(endPeriod, LocalTime.of(23, 59)));
    }

    /**
     * Builds an ArrayList of measurements. This method also filters out any 'bad' measurements
     *
     * Sets the private measurements value to the measurements given from the database
     */
    public void getMeasurements() {
        ArrayList<Measurement> measurements = new ArrayList<>();
        ArrayList<RawMeasurement> rawMeasurements = getRawMeasurements();
        for (RawMeasurement rawMeasurement : rawMeasurements) {
            Measurement measurement = new Measurement(rawMeasurement);
            if (measurement.isValid()) {
                measurements.add(measurement);
            }
        }
        this.measurements = measurements;
    }


    /**
     * @return average temp of measurement list
     */
    public double getAverageOutsideTemperature() {
        double averageTemp = 0;
        for (Measurement measurement : measurements) {
            averageTemp += measurement.getOutsideTemp();
        }
        averageTemp /= measurements.size();
        return averageTemp;
    }

    /**
     * calculates the starting and ending dates containing the longest draught
     *
     * @param maxRain the maximum amount of rain until something is not considered as draught anymore
     * @return the longest sub-period that had less than a given amount of rain
     */
    public Period longestDraught(int maxRain) {
        int startIdx = 0;
        int endIdx = 0;
        maxRain *= 60; //total rain is not converted from /hr to /min but will be assumed 60-fold
        int totalRain = 0;
        int deltaTime = 0;
        LocalDate startDate = this.beginPeriod;
        LocalDate endDate = this.beginPeriod;
        Period period = new Period();
        while (endIdx < measurements.size()) {
            if (endIdx < startIdx) {
                // in case there's too much rain and the start index gets pushed over the end index
                endIdx = startIdx;
                totalRain = 0;
            }
            if (endIdx > 0 && ChronoUnit.HOURS.between(measurements.get(endIdx - 1).getDateStamp(), measurements.get(endIdx).getDateStamp()) >= 2) {
                // too big of a time interval
                startIdx = ++endIdx;
                totalRain = 0;
                if (endIdx >= measurements.size())
                    break;
                startDate = measurements.get(startIdx).getDateStamp().toLocalDate();
                endDate = measurements.get(endIdx).getDateStamp().toLocalDate();
            }

            if (endIdx == startIdx || totalRain <= maxRain) {
                // adding elements if possible
                totalRain += measurements.get(endIdx).getRainRate();
                endIdx++;
                if (!endDate.equals(measurements.get(endIdx - 1).getDateStamp().toLocalDate())) {
                    endDate = measurements.get(endIdx - 1).getDateStamp().toLocalDate();
                }
            } else {
                // removing elements if too many
                totalRain -= measurements.get(startIdx).getRainRate();
                startIdx++;
                if (!startDate.equals(measurements.get(startIdx).getDateStamp().toLocalDate())) {
                    startDate = measurements.get(startIdx).getDateStamp().toLocalDate();
                }
            }

            if (ChronoUnit.HOURS.between(measurements.get(startIdx).getDateStamp(), measurements.get(endIdx - 1).getDateStamp()) >= deltaTime) {
                // adjusting the duration and dates if a longer (or equal to get the most recent) span has been found
                deltaTime = (int) ChronoUnit.HOURS.between(measurements.get(startIdx).getDateStamp(), measurements.get(endIdx - 1).getDateStamp());
                period.setStart(startDate);
                period.setEnd(endDate);
            }
        }
        period.getMeasurements();
        return period;
    }

    /**
     * Calculates the median
     *
     * @param type what value of measurement to use to calculate median
     * @return Median of set values
     */
    public double calculateMedian(String type) {
        ArrayList<Double> values = createArrayList(type);
        Collections.sort(createArrayList(type));
        if (values.size() % 2 == 0) {
            double a = values.get(values.size() / 2 - 1);
            double b = values.get(values.size() / 2);
            return (a + b) / 2.0;
        } else {
            int c = values.size() / 2;
            return values.get(c);
        }
    }

    /**
     * Calculates Mode
     *
     * @param type what value of measurement to use to calculate median
     * @return Mode of set values
     */
    public ArrayList<Double> calculateMode(String type) {
        /*
            [2.0,3.0,3.0,6.0,8.0,9.0,9.0]
            Zit waarde al in hashmap dan 1 erbij tellen, anders voeg je hem toe en zet je hem op 1.

            Hoogste is 2, (3.0 en 9.0).
         */
        ArrayList<Double> list = createArrayList(type);
        ArrayList<Double> results = new ArrayList<>();
        HashMap<Double, Integer> hm = new HashMap<>();
        int highestAmount = 0;
        for (double number : list) {
            if (hm.containsKey(number)) {
                hm.put(number, hm.get(number) + 1);
                if (hm.get(number) > highestAmount) highestAmount = hm.get(number);
            } else {
                hm.put(number, 1);
            }
        }
        if (highestAmount > 0) {
            for (double i : hm.keySet()) {
                if (hm.get(i) == highestAmount)
                    results.add(i);
            }
        }
        return results;

    }

    /**
     * Calculates mean
     *
     * @param type what value of measurement to use to calculate median
     * @return Mean of set values
     */
    public double calculateMean(String type) {
        ArrayList<Double> list = createArrayList(type);
        double total = 0;
        for (double number : list) {
            total += number;
        }
        return total / list.size();
    }

    /**
     * Calculates the standardDeviation
     *
     * @param type what value of measurement to use to calculate median
     * @return StandardDeviation of set values
     */
    public double calculateStandardDeviation(String type) {
        ArrayList<Double> list = createArrayList(type);
        double standardDeviation = 0.0;
        double mean = calculateMean(type);
        for (double num : list) {
            standardDeviation += Math.pow(num - mean, 2);
        }
        return Math.sqrt(standardDeviation / list.size());
    }


    /**
     * Determines the lowest value of set list
     *
     * @param type what value of measurement to use to calculate median
     * @return Lowest value of set values
     */
    public double getLowest(String type) {
        ArrayList<Double> list = createArrayList(type);
        double lowest = list.get(0);
        for (double value : list) {
            if (lowest > value)
                lowest = value;
        }
        return lowest;
    }


    /**
     * Determines the highest value of set list
     *
     * @param type what value of measurement to use to calculate median
     * @return Highest value of set values
     */
    public double getHighest(String type) {
        ArrayList<Double> list = createArrayList(type);
        double highest = list.get(0);
        for (double value : list) {
            if (value > highest)
                highest = value;
        }
        return highest;
    }

    public double getHighest(ArrayList<Double> list) {
        double highest = list.get(0);
        for (double value : list) {
            if (value > highest)
                highest = value;
        }
        return highest;
    }

    /**
     * Calculates the max fallen rain consecutive in a period.
     * If the time between 2 measurements is equal or higher than 2, this will stop the loop and start over from the latest measurement.
     *
     * @return the max fallen rain consecutive in a period.
     */
    public double getMaxFallenRainConsecutive() {
        double maxFallenRainConsecutive = 0;
        double currentFallenRainConsecutive = 0;
        if(measurements.size() > 0) {
            LocalDateTime localDateTime = measurements.get(0).getDateStamp();
            for (Measurement measurement : measurements) {
                if (measurement.getRainRate() > 0) {
                    if(ChronoUnit.HOURS.between(localDateTime, measurement.getDateStamp()) >= 2) {
                        if (currentFallenRainConsecutive > maxFallenRainConsecutive)
                            maxFallenRainConsecutive = currentFallenRainConsecutive;
                        currentFallenRainConsecutive = 0;
                    } else {
                        currentFallenRainConsecutive += measurement.getRainRate() / 60;
                    }
                } else {
                    if (currentFallenRainConsecutive > maxFallenRainConsecutive)
                        maxFallenRainConsecutive = currentFallenRainConsecutive;
                    currentFallenRainConsecutive = 0;
                }
                localDateTime = measurement.getDateStamp();
            }
            return maxFallenRainConsecutive;
        }
        return 0;
    }

    public LocalDate getBeginPeriod() {
        return beginPeriod;
    }

    public LocalDate getEndPeriod() {
        return endPeriod;
    }
    /**
     * Calculates the longest consecutive summer days in a given period.
     *
     * If the outside temperature is above 25 degrees, it's checked if the date of the measurement is already in the ArrayList dates. If not the date gets added to the ArrayList.
     * This is being looped for all the measurements of the period. If the ArrayList dates contains nothing NULL is returned. if dates contains 1 date, that 1 date is returned.
     * If dates contains >1, a for loop checks if the difference is 1 day in between this day and the next. While the next object in the ArrayList is the next day, currentCounter goes up by 1.
     * When the next object isn't the next day, the length of current gets compared with longest. if longest is smaller then current, longest gets replaced by current.
     *
     * @return the longest consecutive summer days, period longest.
     */
    public Period summerDays() {
        Period current = new Period();
        Period longest = new Period();
        int longestCounter = 0;
        ArrayList<LocalDate> dates = new ArrayList<>();
        for (Measurement m : measurements) {
            if (m.getOutsideTemp() >= 25) {
                if (!dates.contains(m.getDateStamp().toLocalDate())) {
                    dates.add(m.getDateStamp().toLocalDate());
                }
            }
        }
        if (dates.size() == 0) return null;
        if (dates.size() == 1) {
            current.setStart(dates.get(0));
            current.setEnd(dates.get(0));
            return current;
        }
        for (int i = 0; i < dates.size(); i++) {
            int currentCounter = 0;
            current.setStart(dates.get(i));
            while (i + 1 < dates.size() && ChronoUnit.DAYS.between(dates.get(i),dates.get(i+1)) == 1) {
                currentCounter++;
                i++;
            }
            current.setEnd(dates.get(i));
            if (currentCounter > longestCounter) {
                longestCounter = currentCounter;
                longest = current;
            }
        }
        return longest;
    }

    public ArrayList<Double> createArrayList(String type) {
        ArrayList<Double> values = new ArrayList<>();
        for(Measurement m : measurements) {
            values.add(m.getValue(type));
        }
        return values;
    }

    /**
     * Checks whether there is a chance of fog on any time of the day.
     * If the difference between the dew point and outside temperature is less than 2.50 degrees on a measurement, there is a chance of fog.
     *
     * @return a list of the days with a chance of fog.
     */
    public ArrayList<LocalDate> getChanceOfFog() {
        ArrayList<LocalDate> daysChanceOfFog = new ArrayList<>();
        for(Measurement measurement : measurements) {
            if(Math.abs(measurement.getDewPoint() - measurement.getOutsideTemp()) < 2.50) { // checks if the difference between the dew point and outside temperature is less than 2.50 degrees on any time of the day.
                if(!daysChanceOfFog.contains(measurement.getDateStamp().toLocalDate()))
                    daysChanceOfFog.add(measurement.getDateStamp().toLocalDate());          // if the date isn't included in the ArrayList yet, add it to the ArrayList.
            }
        }
        return daysChanceOfFog;
    }
    /**
     * This method determines the month with the most rain rate for a period of a year.
     * First off we use a hashmap to keep track of the values. This is done by assigning a key to a given value. If we call for the key we get back the value and vice versa.
     * Later we use the highest method in this class to determine the value for which we need to get the key from the hashmap.
     *
     * @return the month with the most rainrate for the year. Since returning an integer wouldn't be very obvious an array list was created that holds the months in string form.
     */
    public String monthWithMostRainRate() {
        HashMap<Integer, Double> rainRateTotalMonth = new HashMap<>();
        ArrayList<String> months = new ArrayList<>(Arrays.asList("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"));
        for (Measurement measurement : measurements) {
            if (measurement.getRainRate() > 0) {
                if (rainRateTotalMonth.containsKey(measurement.getDateStamp().getMonthValue())) {
                    rainRateTotalMonth.put(measurement.getDateStamp().getMonthValue(), rainRateTotalMonth.get(measurement.getDateStamp().getMonthValue()) + measurement.getRainRate()/60);
                } else {
                    rainRateTotalMonth.put(measurement.getDateStamp().getMonthValue(), measurement.getRainRate());
                }
            }
        }
        String endMonth = "";
        double highest = getHighest(new ArrayList<>(rainRateTotalMonth.values()));
        for (int i : rainRateTotalMonth.keySet()) {
            if (rainRateTotalMonth.get(i).equals(highest)) {
                endMonth = months.get(i - 1);
            }
        }
        return endMonth;
    }

    public int getMeasurementsSize() {
        return measurements.size();
    }

    public void print() {
        System.out.println("Printing period: ");
        for(Measurement m : measurements) {
            m.printValidMeasures();
        }
    }

    public Measurement getLatestValidMeasurement() {
        LocalDateTime localDateTime;
        Measurement measurement = measurements.get(0);
        ArrayList<LocalDateTime> values = new ArrayList<>();
        for(Measurement m : measurements) {
            values.add(m.getDateStamp());
        }
        localDateTime = Collections.max(values);
        for(Measurement m : measurements) {
            if(localDateTime.equals(m.getDateStamp())) {
                measurement = m;
            }
        }
        return measurement;
    }
}
