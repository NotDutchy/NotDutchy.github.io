import java.text.DecimalFormat;

public class ConvertMeasure {
    /**
     * airPressure
     *
     * @param rawValue Raw measurement from the vp2pro weather station
     * @return The air pressure in hPa
     */
    public static int airPressure(short rawValue) {
        return (int) Math.round((double) rawValue/1000 * 33.86389);
    }

    /**
     * temperature
     *
     * @param rawValue Raw measurement from the vp2pro weather station
     * @return The temperature in degrees Celsius
     */
    public static double temperature(short rawValue) { return ((rawValue / 10.0) - 32) / 1.8; }

    /**
     * humidity
     *
     * @param rawValue Raw measurement from the vp2pro weather station
     * @return The relative humidity in %
     */
    public static int humidity(short rawValue) {
        return (int) rawValue;
    }

    /**
     * windSpeed
     *
     * @param rawValue Raw measurement from the vp2pro weather station
     * @return The wind speed in km/h
     */
    public static double windSpeed(short rawValue) { return rawValue * 1.609344; }

    /**
     * windDirection
     *
     * @param rawValue Raw measurement from the vp2pro weather station
     * @return The wind direction in degrees
     */
    public static int windDirection(short rawValue) {
        return (int) rawValue;
    }

    /**
     * rainMeter
     *
     * @param rawValue Raw measurement from the vp2pro weather station
     * @return The amount of rain in mm
     */
    public static double rainMeter(short rawValue) {
        return (double) rawValue / 100 * 25.40;
    }

    /**
     * uvIndex
     *
     * @param rawValue Raw measurement from the vp2pro weather station
     * @return The uv index (dimensionless)
     */
    public static double uvIndex(short rawValue) {
        return (double) rawValue / 10;
    }

    /**
     * batteryLevel
     *
     * @param rawValue Raw measurement from the vp2pro weather station
     * @return The battery level in Volt
     */
    public static double batteryLevel(short rawValue) {
        return (double) rawValue * 300 / 512 / 100.0;
    }

    /**
     * sunRise
     *
     * @param rawValue Raw measurement from the vp2pro weather station
     * @return Time in hh:mm notation
     */
    public static String time(short rawValue) {
        return (rawValue / 100) + ":" + ((rawValue % 100 < 10 ? "0" : "") + rawValue % 100);
    }

    /**
     * windChill
     *
     * @param temperature The outside temperature in degrees Celsius
     * @param windSpeed The wind speed in kilometres per hour
     * @return The wind chill in degrees Celsius
     */
    public static double windChill(double temperature, double windSpeed) {
        double windChill = 13.12 + (0.6215 * temperature) - (11.37 * Math.pow(windSpeed, 0.16)) + (0.3965 * temperature * Math.pow(windSpeed, 0.16)); //calculates wind chill
        return windChill;
    }

    /**
     * heatIndex
     *
     * @param temperature The outside temperature in degrees Celsius
     * @param humidity The humidity in percentage
     * @return The heat index in degrees Celsius
     */
    public static double heatIndex(double temperature, int humidity) {
        //the order is shuffled to turn rows and columns into powers of humidity and temperature respectively
        //c1 c2 c5
        //c3 c4 c7
        //c6 c8 c9
        double[][] constants = {
                new double[] {-8.785, 1.611, -0.01231},
                new double[] {2.339, -0.1461, 0.002212},
                new double[] {-0.01642, 0.0007255, -0.000003582}
        };
        double heatIndex = 0;
        for (int r = 0; r < 3; r++) { //scans rows/humidity
            for (int t = 0; t < 3; t++) { //scans columns/temperature
                heatIndex += constants[r][t] * Math.pow(temperature, t) * Math.pow(humidity, r);
            }
        }
        return heatIndex;
    }

    /**
     * dewPoint
     *
     * @param temperature The outside temperature in degrees Celsius
     * @param humidity The humidity in percentage
     * @return The dew point in degrees Celsius
     */
    public static double dewPoint(double temperature, int humidity) { return temperature - (100 - humidity) / 5.0; }

    public static String round(double value, String pattern) {
        DecimalFormat df= new DecimalFormat(pattern);
        return df.format(value);
    }
}
