import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Arrays;

public class Weerstation {

    /*
     * Main method
     * Starts connection to GUIBoard, clears GUIBoard and starts TabManager.
     */
    public static void main(String[] args) {
        IO.init();
        DatabaseConnection.clearCache();
        TabManager tabManager = new TabManager();
    }
}