

/*
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class TestConverter {

    @Test
    public void testTemperature() {
        assertEquals(ConvertMeasure.temperature((short)763),24.61, 0.2);
    }

    @Test
    public void testWind() {
        assertEquals(ConvertMeasure.windSpeed((short)14),22.5, 0.2);
    }

    @Test
    public void testBarometer() {
        assertEquals(ConvertMeasure.airPressure((short)30084),1019, 0.2);
    }

    @Test
    public void testHumidity() {
        assertEquals(ConvertMeasure.humidity((short)32),32, 0.2);
    }

    @Test
    public void testRainRate() {
        assertEquals(ConvertMeasure.rainMeter((short)173),44, 0.2);
    }

    @Test
    public void testWindDirection() {
        assertEquals(ConvertMeasure.windDirection((short)293),293, 0.2);
    }

    @Test
    public void testBatLevel() {
        assertEquals(ConvertMeasure.batteryLevel((short)193),1.13, 0.2);
    }

    @Test
    public void testUVLevel() {
        assertEquals(ConvertMeasure.uvIndex((short)66),6.6, 0.2);
    }

    @Test
    public void testTime() {
        assertEquals(ConvertMeasure.time((short)2202),"22:02");
    }








}
*/